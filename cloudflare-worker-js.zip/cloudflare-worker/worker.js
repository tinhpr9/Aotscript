import {
  checkActiveRollout,
  getActiveRollout,
  handleRolloutCallback,
  handleRolloutCommand,
  isRolloutMetadataKey,
} from "./rollout.js";
import { FleetState } from "./fleet-state.js";
import {
  fleetStateStub,
  fleetStateCall,
  listFleetDeviceRecords,
  getFleetDeviceRecord,
  setFleetDeviceRevocation,
  enqueueFastCommand,
} from "./fleet-state-client.js";
export { FleetState };

const OWNER = "tinhpr9";
const REPO = "Aotscript";
const BRANCH = "main";

const TARGET_FILES = {
  all: "lenh_all.txt",
  marmot: "lenh_marmot.txt",
  nova: "lenh_nova.txt",
};

const DEFAULT_GROUP_LABELS = {
  MARMOT: "NHÓM 1",
  NOVA: "NHÓM 2",
};

const DEVICE_ALIAS_PREFIX = "device_alias:";
const GROUP_LABEL_PREFIX = "group_label:";
const PAIR_PREFIX = "pair:";
const PAIR_DEVICE_PREFIX = "pair_device:";
const PAIR_RATE_PREFIX = "pair_rate:";
const PAIR_TTL_SECONDS = 10 * 60;
const PAIR_RATE_SECONDS = 60;
const MAINTENANCE_PREFIX = "maintenance:";
const REVOKED_PREFIX = "revoked:";
const HEALTH_STATE_PREFIX = "health_state:";
const SETTING_PREFIX = "setting:";
const GROUP_NUMBER_MIGRATION_KEY =
  `${SETTING_PREFIX}numbered_groups_v1`;
const ALERTS_SETTING_KEY =
  `${SETTING_PREFIX}alerts_enabled`;
const HEALTH_BOOTSTRAP_KEY =
  `${SETTING_PREFIX}health_bootstrapped`;
const OFFLINE_ALERT_AFTER_MS =
  3 * 60 * 1000;
const RECENT_ERROR_WINDOW_MS =
  24 * 60 * 60 * 1000;
const LOW_BATTERY_PERCENT = 15;
const BATTERY_RECOVERY_PERCENT = 20;
const LOW_STORAGE_BYTES =
  2 * 1024 * 1024 * 1024;
const STORAGE_RECOVERY_BYTES =
  3 * 1024 * 1024 * 1024;
const QUIET_HOUR_START = 23;
const QUIET_HOUR_END = 7;
const COMMAND_TTL_MS = 5 * 60 * 1000;
const DEFERRED_COMMAND_TTL_MS =
  24 * 60 * 60 * 1000;
const MAX_PENDING_COMMAND_BLOCKS = 256;
const MAX_PENDING_COMMAND_BYTES =
  256 * 1024;
const COMMAND_METADATA_TTL_SECONDS = 30 * 24 * 60 * 60;
const ONLINE_WINDOW_MS = 90 * 1000;
const TARGETING_AGENT_VERSION = "fleet-ops-1";
const DANGEROUS_COMMAND_KEYS = new Set([
  "setup_boot",
  "setup_caylapbu",
  "run_caylapbu",
  "update_delta",
  "repair",
  "reboot",
]);

const COMMANDS = {
  idle: { value: "IDLE", bit: 1, label: "💤 IDLE" },
  setup_vip: { value: "SETUP_VIP", bit: 2, label: "⚙️ VIP" },
  install_track: { value: "INSTALL_TRACK", bit: 4, label: "📡 TRACK" },
  setup_boot: { value: "SETUP_BOOT", bit: 8, label: "🔧 BOOT" },
  setup_caylapbu: { value: "SETUP_CAYLAPBU", bit: 16, label: "🌱 CÀI CAYLAPBU" },
  run_caylapbu: { value: "RUN_CAYLAPBU", bit: 32, label: "▶️ CHẠY CAYLAPBU" },
  update_delta: { value: "UPDATE_DELTA", bit: 64, label: "🔁 DELTA" },
  repair: { value: "RECONCILE_SYSTEM", bit: 2048, label: "🛠 TỰ SỬA" },
  update_solver: { value: "UPDATE_SOLVER", bit: 256, label: "🧠 SOLVER" },
  update_script: { value: "UPDATESCRIPT", bit: 512, label: "📝 SCRIPT" },

  reload_novagag2: {
    value: "RELOAD_NOVAGAG2",
    bit: 1024,
    label: "🔄 NOVAGAG2",
  },

  reboot: { value: "REBOOT", bit: 128, label: "🔌 REBOOT" },
};

const COMMAND_ORDER = [
  "idle",
  "setup_vip",
  "install_track",
  "setup_boot",
  "setup_caylapbu",
  "run_caylapbu",
  "update_delta",
  "repair",
  "update_solver",
  "update_script",
  "reboot",
];

const ALLOWED_REPORT_STATUSES = [
  "heartbeat",
  "received",
  "running",
  "success",
  "error",
  "expired",
];



function normalizeDeviceId(value) {
  const raw = String(value || "").trim();

  const dynamicMatch =
    raw.match(/^m([1-9]\d{0,5})$/i);

  if (dynamicMatch) {
    return `m${dynamicMatch[1]}`;
  }

  const legacyMatch =
    raw.match(/^(MARMOT|NOVA)-(\d{2})$/i);

  if (!legacyMatch) return null;

  const group = legacyMatch[1].toUpperCase();
  const index = Number(legacyMatch[2]);

  if (index < 1 || index > 10) {
    return null;
  }

  return `${group}-${String(index).padStart(2, "0")}`;
}

function normalizeDeviceGroup(value) {
  const group =
    String(value || "").trim().toUpperCase();

  return ["MARMOT", "NOVA"].includes(group)
    ? group
    : null;
}

function normalizeGroupInput(value) {
  const raw = String(value || "")
    .trim()
    .toUpperCase()
    .replace(/[\s_-]+/g, "");

  if (
    ["1", "NHOM1", "GROUP1", "MARMOT"].includes(raw)
  ) {
    return "MARMOT";
  }

  if (
    ["2", "NHOM2", "GROUP2", "NOVA"].includes(raw)
  ) {
    return "NOVA";
  }

  return null;
}

function normalizeTargetInput(value) {
  const raw = String(value || "")
    .trim()
    .toLowerCase();

  if (raw === "all") {
    return "all";
  }

  const group =
    normalizeGroupInput(raw);

  if (group === "MARMOT") {
    return "marmot";
  }

  if (group === "NOVA") {
    return "nova";
  }

  return null;
}

async function ensureNumberedGroupLabels(env) {
  const migrated =
    await env.DEVICE_STATUS.get(
      GROUP_NUMBER_MIGRATION_KEY
    );

  if (migrated === "1") {
    return;
  }

  await Promise.all([
    env.DEVICE_STATUS.put(
      `${GROUP_LABEL_PREFIX}MARMOT`,
      DEFAULT_GROUP_LABELS.MARMOT
    ),
    env.DEVICE_STATUS.put(
      `${GROUP_LABEL_PREFIX}NOVA`,
      DEFAULT_GROUP_LABELS.NOVA
    ),
    env.DEVICE_STATUS.put(
      GROUP_NUMBER_MIGRATION_KEY,
      "1"
    ),
  ]);
}


function sanitizeLabel(value, maxLength = 48) {
  const label = String(value || "")
    .replace(/[\u0000-\u001f\u007f]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  if (!label || label.length > maxLength) {
    return null;
  }

  return label;
}

function isDeviceStatusMetadataKey(name) {
  return (
    name === "latest_command" ||
    name.startsWith("cmd:") ||
    name.startsWith(DEVICE_ALIAS_PREFIX) ||
    name.startsWith(GROUP_LABEL_PREFIX) ||
    name.startsWith(PAIR_PREFIX) ||
    name.startsWith(PAIR_DEVICE_PREFIX) ||
    name.startsWith(PAIR_RATE_PREFIX) ||
    name.startsWith(MAINTENANCE_PREFIX) ||
    name.startsWith(REVOKED_PREFIX) ||
    name.startsWith(HEALTH_STATE_PREFIX) ||
    isRolloutMetadataKey(name) ||
    name.startsWith(SETTING_PREFIX)
  );
}

async function getDeviceAlias(deviceId, env) {
  try {
    const value = await env.DEVICE_STATUS.get(
      `${DEVICE_ALIAS_PREFIX}${deviceId}`
    );
    return sanitizeLabel(value, 48);
  } catch (error) {
    return null;
  }
}

async function getGroupLabel(group, env) {
  const normalized =
    normalizeDeviceGroup(group);

  if (!normalized) {
    return String(group || "-").toUpperCase();
  }

  try {
    const value =
      await env.DEVICE_STATUS.get(
        `${GROUP_LABEL_PREFIX}${normalized}`
      );

    return (
      sanitizeLabel(value, 32) ||
      DEFAULT_GROUP_LABELS[normalized]
    );
  } catch (error) {
    return (
      DEFAULT_GROUP_LABELS[normalized] ||
      normalized
    );
  }
}

async function getTargetLabel(target, env) {
  if (target === "all") {
    return "TẤT CẢ";
  }
  return getGroupLabel(target, env);
}

function compareDeviceIds(left, right) {
  return left.localeCompare(
    right,
    undefined,
    {
      numeric: true,
      sensitivity: "base",
    }
  );
}


async function reportFleetDevice(
  env,
  payload
) {
  let result =
    await fleetStateCall(
      env,
      "/report",
      {
        method: "POST",
        body: payload,
      }
    );
  if (
    result.response.status === 409 &&
    result.data?.error ===
      "revocation_unknown"
  ) {
    const revoked =
      await isDeviceRevoked(
        payload.device_id,
        env
      );
    result =
      await fleetStateCall(
        env,
        "/report",
        {
          method: "POST",
          body: {
            ...payload,
            revocation_checked:
              true,
            revoked,
          },
        }
      );
  }
  return result;
}

async function handleAgentCommandWebSocket(
  request,
  env,
  url
) {
  if (!isAuthorizedAgentRequest(request, env)) {
    return noStoreJson(
      { ok: false, error: "unauthorized" },
      401
    );
  }

  if (
    String(request.headers.get("Upgrade") || "").toLowerCase()
    !== "websocket"
  ) {
    return noStoreJson(
      { ok: false, error: "upgrade_required" },
      426
    );
  }

  const deviceId = normalizeDeviceId(
    url.searchParams.get("device_id")
  );

  if (!deviceId) {
    return noStoreJson(
      { ok: false, error: "invalid_device_id" },
      400
    );
  }

  if (await isDeviceRevoked(deviceId, env)) {
    return noStoreJson(
      { ok: false, error: "device_revoked" },
      410
    );
  }

  return fleetStateStub(env).fetch(
    new Request(
      `https://fleet-state.internal/command/ws?id=${encodeURIComponent(deviceId)}`,
      {
        method: "GET",
        headers: { Upgrade: "websocket" },
      }
    )
  );
}


const AOT_PROTOCOL_VERSION = "phase3-1";
const AOT_MAX_JSON_BYTES = 384 * 1024;
const AOT_MAX_TARGETS = 128;
const AOT_ACTION_TTL_MAX_MS = 30 * 1000;

function normalizeAotSessionId(value) {
  const raw = String(value || "").trim();
  return /^[A-Za-z0-9_-]{1,64}$/.test(raw)
    ? raw
    : null;
}

function normalizeAotActionId(value) {
  const raw = String(value || "").trim();
  return /^[A-Za-z0-9_-]{1,128}$/.test(raw)
    ? raw
    : null;
}

function normalizeAotFingerprint(value) {
  const raw = String(value || "").trim().toLowerCase();
  return /^[a-f0-9]{24}$/.test(raw)
    ? raw
    : null;
}

async function readAotJson(request) {
  const length = Number(
    request.headers.get("Content-Length") || 0
  );
  if (
    Number.isFinite(length) &&
    length > AOT_MAX_JSON_BYTES
  ) {
    return { error: "payload_too_large" };
  }
  const raw = await request.text();
  if (
    new TextEncoder().encode(raw).length >
    AOT_MAX_JSON_BYTES
  ) {
    return { error: "payload_too_large" };
  }
  try {
    const value = JSON.parse(raw);
    return (
      value &&
      typeof value === "object" &&
      !Array.isArray(value)
    )
      ? { value }
      : { error: "invalid_json_body" };
  } catch (error) {
    return { error: "invalid_json_body" };
  }
}

function normalizeAotAction(value) {
  if (!value || typeof value !== "object") {
    return null;
  }
  const kind = String(value.kind || "");
  if (kind === "tap_selector") {
    const resourceId = String(
      value.resource_id || ""
    ).trim();
    if (
      !resourceId ||
      resourceId.length > 200 ||
      /[\u0000-\u001f\u007f]/.test(resourceId)
    ) {
      return null;
    }
    return {
      kind,
      resource_id: resourceId,
    };
  }
  if (kind === "back") {
    return { kind };
  }
  if (kind === "swipe") {
    const values = [
      Number(value.x1),
      Number(value.y1),
      Number(value.x2),
      Number(value.y2),
    ];
    if (
      values.some(
        (item) =>
          !Number.isFinite(item) ||
          item < 0 ||
          item > 1
      )
    ) {
      return null;
    }
    const duration = Math.min(
      5000,
      Math.max(
        50,
        Number(value.duration_ms) || 300
      )
    );
    return {
      kind,
      x1: values[0],
      y1: values[1],
      x2: values[2],
      y2: values[3],
      duration_ms: Math.round(duration),
    };
  }
  return null;
}

async function handleAotControlWebSocket(
  request,
  env,
  url
) {
  if (!isAuthorizedAgentRequest(request, env)) {
    return noStoreJson(
      { ok: false, error: "unauthorized" },
      401
    );
  }
  if (
    String(
      request.headers.get("Upgrade") || ""
    ).toLowerCase() !== "websocket"
  ) {
    return noStoreJson(
      { ok: false, error: "upgrade_required" },
      426
    );
  }
  const deviceId = normalizeDeviceId(
    url.searchParams.get("device_id")
  );
  if (
    !deviceId
  ) {
    return noStoreJson(
      { ok: false, error: "invalid_aot_socket" },
      400
    );
  }
  if (await isDeviceRevoked(deviceId, env)) {
    return noStoreJson(
      { ok: false, error: "device_revoked" },
      410
    );
  }
  const query = new URLSearchParams({ id: deviceId });
  return fleetStateStub(env).fetch(
    new Request(
      `https://fleet-state.internal/aot/ws?${query.toString()}`,
      {
        method: "GET",
        headers: { Upgrade: "websocket" },
      }
    )
  );
}

async function handleAotControlAction(
  request,
  env
) {
  if (!isAuthorizedAgentRequest(request, env)) {
    return noStoreJson(
      { ok: false, error: "unauthorized" },
      401
    );
  }
  const parsed = await readAotJson(request);
  if (parsed.error) {
    return noStoreJson(
      { ok: false, error: parsed.error },
      400
    );
  }
  const body = parsed.value;
  const sessionId = normalizeAotSessionId(
    body.session_id
  );
  const referenceId = normalizeDeviceId(
    body.reference_device_id
  );
  const actionId = normalizeAotActionId(
    body.action_id
  );
  const precondition = normalizeAotFingerprint(
    body.precondition
  );
  const action = normalizeAotAction(body.action);
  const expiresAt = Number(body.expires_at);
  const rawTargets = Array.isArray(
    body.target_device_ids
  )
    ? body.target_device_ids
    : [];
  const targets = [];
  const seen = new Set();
  for (const raw of rawTargets) {
    const deviceId = normalizeDeviceId(raw);
    if (
      deviceId &&
      !seen.has(deviceId)
    ) {
      seen.add(deviceId);
      targets.push(deviceId);
    }
  }
  const now = Date.now();
  if (
    body.protocol !== AOT_PROTOCOL_VERSION ||
    !sessionId ||
    !referenceId ||
    !actionId ||
    !precondition ||
    !action ||
    !Number.isFinite(expiresAt) ||
    expiresAt <= now ||
    expiresAt - now > AOT_ACTION_TTL_MAX_MS ||
    targets.length < 1 ||
    targets.length > AOT_MAX_TARGETS
  ) {
    return noStoreJson(
      { ok: false, error: "invalid_aot_action" },
      400
    );
  }
  if (await isDeviceRevoked(referenceId, env)) {
    return noStoreJson(
      { ok: false, error: "device_revoked" },
      410
    );
  }
  for (const target of targets) {
    if (await isDeviceRevoked(target, env)) {
      return noStoreJson(
        {
          ok: false,
          error: "target_device_revoked",
          device_id: target,
        },
        410
      );
    }
  }
  const result = await fleetStateCall(
    env,
    "/aot/action",
    {
      method: "POST",
      body: {
        protocol: AOT_PROTOCOL_VERSION,
        session_id: sessionId,
        reference_device_id: referenceId,
        target_device_ids: targets,
        action_id: actionId,
        expires_at: expiresAt,
        precondition,
        action,
      },
    }
  );
  return noStoreJson(
    result.data,
    result.response.status
  );
}

async function handleAotControlAck(
  request,
  env
) {
  if (!isAuthorizedAgentRequest(request, env)) {
    return noStoreJson(
      { ok: false, error: "unauthorized" },
      401
    );
  }
  const parsed = await readAotJson(request);
  if (parsed.error) {
    return noStoreJson(
      { ok: false, error: parsed.error },
      400
    );
  }
  const body = parsed.value;
  const deviceId = normalizeDeviceId(body.device_id || body.follower_device_id);
  const actionId = normalizeAotActionId(
    body.action_id
  );
  const status = String(body.status || "");
  const batchAction = String(body.batch_action || "");
  const isBatch = [AOT_HUB_PROTOCOL_VERSION, "phase4-1"].includes(body.protocol) &&
    ["OPEN_SWIFT_BACKUP", "OPEN_SWIFT_APPS", "BACKUP_RESTORE_DATA", "UPDATE_WORKER", "ALLOCATE_SERVER"].includes(batchAction);
  const allowedStatus = new Set(
    batchAction === "UPDATE_WORKER"
      ? ["DOWNLOADING", "VERIFIED", "INSTALLING", "RESTARTING", "HEALTHY", "ROLLED_BACK", "FAILED"]
      : isBatch
      ? (
          batchAction === "BACKUP_RESTORE_DATA"
          ? [
              "ACCEPTED",
              "SWIFT_OPENED",
              "APPS_OPENED",
              "FILTERED",
              "SELECTED",
              "OPTIONS_VERIFIED",
              "BACKUP_STARTED",
              "FAILED_NOT_INSTALLED",
              "FAILED",
              "TIMEOUT",
              "DUPLICATE",
            ]
          : batchAction === "ALLOCATE_SERVER"
          ? [
              "PREPARE_SENT",
              "PREPARE_READY",
              "PREPARE_FAILED",
              "COMMIT_SENT",
              "ABORT_SENT",
              "ACCEPTED",
              "ALLOCATED",
              "OPENED",
              "FAILED_NOT_INSTALLED",
              "FAILED",
              "TIMEOUT",
              "DUPLICATE",
            ]
          : [
              "ACCEPTED",
              "OPENED",
              "APPS_OPENED",
              "FAILED_NOT_INSTALLED",
              "FAILED",
              "TIMEOUT",
              "DUPLICATE",
            ]
        )
      : [
          "success",
          "duplicate",
          "out_of_sync",
          "expired",
          "error",
        ]
  );
  let preview = null;
  if (
    typeof body.preview_b64 === "string" &&
    body.preview_b64
  ) {
    if (
      body.preview_b64.length > 256 * 1024 ||
      !/^[A-Za-z0-9+/=]+$/.test(
        body.preview_b64
      )
    ) {
      return noStoreJson(
        {
          ok: false,
          error: "invalid_preview",
        },
        400
      );
    }
    preview = body.preview_b64;
  }
  if (
    !isBatch || !deviceId ||
    !actionId ||
    !allowedStatus.has(status)
  ) {
    return noStoreJson(
      { ok: false, error: "invalid_aot_ack" },
      400
    );
  }
  const clean = {
    protocol: isBatch
      ? AOT_HUB_PROTOCOL_VERSION
      : AOT_PROTOCOL_VERSION,
    device_id: deviceId,
    action_id: actionId,
    status,
    executed: body.executed === true,
    screen_changed: body.screen_changed === true,
  };
  if (isBatch) {
    clean.batch_action = batchAction;
    if (batchAction === "UPDATE_WORKER") {
      clean.worker_version = String(body.worker_version || "").slice(0, 80);
      clean.channel = ["canary", "stable"].includes(body.channel) ? body.channel : "";
    } else if (batchAction === "BACKUP_RESTORE_DATA") {
      if (typeof body.reason === "string") {
        clean.reason = body.reason.trim().slice(0, 160);
      }
      if (Number.isSafeInteger(body.app_count) && body.app_count >= 0 && body.app_count <= 100000) {
        clean.app_count = body.app_count;
      }
      if (Number.isSafeInteger(body.selected_count) && body.selected_count >= 0 && body.selected_count <= 100000) {
        clean.selected_count = body.selected_count;
      }
    } else if (batchAction === "ALLOCATE_SERVER") {
      if (typeof body.reason === "string") {
        clean.reason = body.reason.trim().slice(0, 160);
      }
    }
  }
  for (const key of [
    "before_fingerprint",
    "after_fingerprint",
    "preview_sha256",
  ]) {
    if (
      typeof body[key] === "string" &&
      body[key].length <= 80
    ) {
      clean[key] = body[key];
    }
  }
  if (
    Number.isFinite(Number(body.preview_bytes)) &&
    Number(body.preview_bytes) >= 0
  ) {
    clean.preview_bytes = Math.floor(
      Number(body.preview_bytes)
    );
  }
  const result = await fleetStateCall(
    env,
    "/aot/ack",
    {
      method: "POST",
      body: clean,
    }
  );
  return noStoreJson(
    result.data,
    result.response.status
  );
}

async function handleAotControlHealth(
  request,
  env
) {
  if (!isAuthorizedAgentRequest(request, env)) {
    return noStoreJson(
      { ok: false, error: "unauthorized" },
      401
    );
  }
  return noStoreJson({
    ok: true,
    protocol: AOT_PROTOCOL_VERSION,
  });
}

async function handleAotRegistration(request, env, operation) {
  if (!isAuthorizedAgentRequest(request, env)) {
    return noStoreJson({ ok: false, error: "unauthorized" }, 401);
  }
  const parsed = await readAotJson(request);
  if (parsed.error) {
    return noStoreJson({ ok: false, error: parsed.error }, 400);
  }
  const rawBody = parsed.value;
  if (!rawBody || typeof rawBody !== "object" || Array.isArray(rawBody)) {
    return noStoreJson({ ok: false, error: "invalid_registration_request" }, 400);
  }
  // Reject forbidden legacy identity fields fail-closed
  const forbiddenKeys = ["role", "session_id", "reference_device_id"];
  for (const forbidden of forbiddenKeys) {
    if (Object.prototype.hasOwnProperty.call(rawBody, forbidden)) {
      return noStoreJson({ ok: false, error: "forbidden_registration_field" }, 400);
    }
  }

  let canonicalBody;
  if (operation === "discover") {
    if (!rawBody.device_id) {
      return noStoreJson({ ok: false, error: "invalid_device_id" }, 400);
    }
    const deviceId = normalizeDeviceId(rawBody.device_id);
    if (!deviceId) {
      return noStoreJson({ ok: false, error: "invalid_device_id" }, 400);
    }
    let previousDeviceId = null;
    if (rawBody.previous_device_id !== undefined && rawBody.previous_device_id !== null && rawBody.previous_device_id !== "") {
      previousDeviceId = normalizeDeviceId(rawBody.previous_device_id);
      if (!previousDeviceId) {
        return noStoreJson({ ok: false, error: "invalid_device_id" }, 400);
      }
    }
    if (await isDeviceRevoked(deviceId, env)) {
      return noStoreJson({ ok: false, error: "device_revoked" }, 410);
    }
    canonicalBody = {
      device_id: deviceId,
      previous_device_id: previousDeviceId,
      device_group: rawBody.device_group ? String(rawBody.device_group).toUpperCase() : "",
    };
  } else if (operation === "verify") {
    if (!rawBody.device_id) {
      return noStoreJson({ ok: false, error: "invalid_device_id" }, 400);
    }
    const deviceId = normalizeDeviceId(rawBody.device_id);
    if (!deviceId) {
      return noStoreJson({ ok: false, error: "invalid_device_id" }, 400);
    }
    if (await isDeviceRevoked(deviceId, env)) {
      return noStoreJson({ ok: false, error: "device_revoked" }, 410);
    }
    canonicalBody = { device_id: deviceId };
  } else if (operation === "reset") {
    if (!rawBody.old_device_id || !rawBody.new_device_id) {
      return noStoreJson({ ok: false, error: "invalid_identity_reset" }, 400);
    }
    const oldDeviceId = normalizeDeviceId(rawBody.old_device_id);
    const newDeviceId = normalizeDeviceId(rawBody.new_device_id);
    if (!oldDeviceId || !newDeviceId || oldDeviceId === newDeviceId) {
      return noStoreJson({ ok: false, error: "invalid_identity_reset" }, 400);
    }
    if (await isDeviceRevoked(oldDeviceId, env) || await isDeviceRevoked(newDeviceId, env)) {
      return noStoreJson({ ok: false, error: "device_revoked" }, 410);
    }
    canonicalBody = { old_device_id: oldDeviceId, new_device_id: newDeviceId };
  } else {
    return noStoreJson({ ok: false, error: "invalid_registration_operation" }, 400);
  }

  const result = await fleetStateCall(env, `/aot/registration/${operation}`, {
    method: "POST",
    body: canonicalBody,
  });
  return noStoreJson(result.data, result.response.status);
}


const AOT_HUB_PROTOCOL_VERSION = "fleet-batch-v1";

function bytesToHex(bytes) {
  return Array.from(bytes)
    .map(
      (byte) =>
        byte.toString(16).padStart(2, "0")
    )
    .join("");
}

async function hmacSha256Bytes(
  keyBytes,
  dataBytes
) {
  const key = await crypto.subtle.importKey(
    "raw",
    keyBytes,
    {
      name: "HMAC",
      hash: "SHA-256",
    },
    false,
    ["sign"]
  );
  const signature =
    await crypto.subtle.sign(
      "HMAC",
      key,
      dataBytes
    );
  return new Uint8Array(signature);
}


function parseTongHopLink(text, target_device_ids, tabs) {

  const pkgs = [
    "com.tinh.vv.hi",
    "com.tinh.vv.hj",
    "com.tinh.vv.hk",
    "com.tinh.vv.hl",
    "com.tinh.vv.hm",
    "com.tinh.vv.hn",
    "com.tinh.vv.ho",
    "com.tinh.vv.hp",
    "com.tinh.vv.hq",
    "com.tinh.vv.hr"
  ];
  if (!Array.isArray(target_device_ids) || target_device_ids.length === 0) {
    throw new Error("Danh sách thiết bị không hợp lệ.");
  }
  const seenDeviceIds = new Set();
  for (const id of target_device_ids) {
    if (typeof id !== "string" || !id.trim()) {
      throw new Error("Danh sách thiết bị không hợp lệ.");
    }
    const normalized = id.trim().toLowerCase();
    if (seenDeviceIds.has(normalized)) {
      throw new Error(`Device ID bị lặp: ${id}`);
    }
    seenDeviceIds.add(normalized);
  }
  if (!Number.isInteger(tabs) || tabs < 1 || tabs > 10) {
    throw new Error("Số tab phải từ 1 đến 10.");
  }

  const lines = String(text || "").split("\n");
  const validUrls = [];
  const seenUrls = new Set();
  const urlRegex = /^https:\/\/(www\.)?roblox\.com\/games\/\d+\?[pP][rR][iI][vV][aA][tT][eE][sS][eE][rR][vV][eE][rR][lL][iI][nN][kK][cC][oO][dD][eE]=[0-9a-fA-F]+$/;

  for (let rawLine of lines) {
    let line = rawLine.trim();
    if (!line || line === "===") continue;
    if (line.includes(",")) {
      const commaIndex = line.lastIndexOf(",");
      line = line.slice(commaIndex + 1).trim();
    }
    if (urlRegex.test(line)) {
      const canonicalUrl = line.replace(/\?[pP][rR][iI][vV][aA][tT][eE][sS][eE][rR][vV][eE][rR][lL][iI][nN][kK][cC][oO][dD][eE]=/, '?privateServerLinkCode=');
      if (!seenUrls.has(canonicalUrl)) {
        seenUrls.add(canonicalUrl);
        validUrls.push(canonicalUrl);
      }
    }
  }

  const requiredCount = target_device_ids.length * tabs;
  if (validUrls.length < requiredCount) {
    throw new Error(
      `Không đủ URL hợp lệ! Cần ${requiredCount} URL (${target_device_ids.length} thiết bị × ${tabs} tab), nhưng chỉ có ${validUrls.length} URL khả dụng.`
    );
  }

  const allocationMap = {};
  for (let i = 0; i < target_device_ids.length; i++) {
    const deviceId = target_device_ids[i];
    const slice = validUrls.slice(i * tabs, (i + 1) * tabs);
    allocationMap[deviceId] = slice.map((url, tabIdx) => ({
      pkg: pkgs[tabIdx],
      url
    }));
  }
  return allocationMap;
}





async function deviceIdsForTarget(target, env) {
  const wantedGroup =
    target === "all"
      ? null
      : normalizeDeviceGroup(target);
  if (target !== "all" && !wantedGroup) {
    throw new Error(
      `Invalid device target: ${target}`
    );
  }
  const ids = new Set();
  try {
    const durableRecords =
      await listFleetDeviceRecords(
        env
      );
    for (
      const record
      of durableRecords
    ) {
      const deviceId =
        normalizeDeviceId(
          record?.device_id
        );
      const deviceGroup =
        normalizeDeviceGroup(
          record?.device_group
        );
      if (
        !deviceId ||
        !deviceGroup ||
        (
          wantedGroup &&
          deviceGroup !== wantedGroup
        )
      ) {
        continue;
      }
      if (
        await isDeviceRevoked(
          deviceId,
          env
        )
      ) {
        continue;
      }
      ids.add(deviceId);
    }
  } catch (error) {
    console.error(
      "fleet_state_list_failed",
      error?.message || error
    );
  }
  let cursor;
  do {
    const page =
      await env.DEVICE_STATUS.list({
        limit: 1000,
        ...(cursor
          ? { cursor }
          : {}),
      });
    for (
      const item
      of page.keys || []
    ) {
      if (
        isDeviceStatusMetadataKey(
          item.name
        )
      ) {
        continue;
      }
      const record =
        await getDeviceRecord(
          item.name,
          env
        );
      if (!record) continue;
      const deviceId =
        normalizeDeviceId(
          record.device_id ||
          item.name
        );
      const deviceGroup =
        normalizeDeviceGroup(
          record.device_group
        );
      if (
        !deviceId ||
        !deviceGroup ||
        (
          wantedGroup &&
          deviceGroup !== wantedGroup
        )
      ) {
        continue;
      }
      ids.add(deviceId);
    }
    cursor =
      page.list_complete
        ? undefined
        : page.cursor;
  } while (cursor);
  return [...ids].sort(
    compareDeviceIds
  );
}



function maintenanceKey(deviceId) {
  return `${MAINTENANCE_PREFIX}${deviceId}`;
}

async function isDeviceMaintenance(deviceId, env) {
  return (
    await env.DEVICE_STATUS.get(
      maintenanceKey(deviceId)
    )
  ) === "1";
}

async function setDeviceMaintenance(
  deviceId,
  enabled,
  env
) {
  if (enabled) {
    await env.DEVICE_STATUS.put(
      maintenanceKey(deviceId),
      "1"
    );
  } else {
    await env.DEVICE_STATUS.delete(
      maintenanceKey(deviceId)
    );
  }
}

function revokedKey(deviceId) {
  return `${REVOKED_PREFIX}${deviceId}`;
}

async function isDeviceRevoked(
  deviceId,
  env
) {
  return (
    await env.DEVICE_STATUS.get(
      revokedKey(deviceId)
    )
  ) !== null;
}

async function deleteKvPrefix(
  prefix,
  env
) {
  let cursor;

  do {
    const page =
      await env.DEVICE_STATUS.list({
        prefix,
        limit: 1000,
        ...(cursor ? { cursor } : {}),
      });

    await Promise.all(
      (page.keys || []).map(
        (item) =>
          env.DEVICE_STATUS.delete(
            item.name
          )
      )
    );

    cursor =
      page.list_complete
        ? undefined
        : page.cursor;
  } while (cursor);
}

function pendingRevocationCacheKey(
  token
) {
  return (
    "https://aotscript.local/" +
    `pending-revocation/${token}`
  );
}

async function savePendingRevocation(
  token,
  deviceId
) {
  await caches.default.put(
    new Request(
      pendingRevocationCacheKey(
        token
      )
    ),
    new Response(
      JSON.stringify({
        device_id: deviceId,
        created: Date.now(),
      }),
      {
        headers: {
          "Content-Type":
            "application/json",
        },
      }
    )
  );
}

async function loadPendingRevocation(
  token
) {
  const response =
    await caches.default.match(
      new Request(
        pendingRevocationCacheKey(
          token
        )
      )
    );

  if (!response) return null;

  try {
    const value = JSON.parse(
      await response.text()
    );

    if (
      !value ||
      typeof value.created !==
        "number" ||
      Date.now() - value.created >
        COMMAND_TTL_MS
    ) {
      await clearPendingRevocation(
        token
      );
      return null;
    }

    const deviceId =
      normalizeDeviceId(
        value.device_id
      );

    if (!deviceId) {
      await clearPendingRevocation(
        token
      );
      return null;
    }

    return {
      device_id: deviceId,
      created: value.created,
    };
  } catch (error) {
    await clearPendingRevocation(
      token
    );
    return null;
  }
}

async function clearPendingRevocation(
  token
) {
  await caches.default.delete(
    new Request(
      pendingRevocationCacheKey(
        token
      )
    )
  );
}

async function requestPermanentDelete(
  chatId,
  rawDeviceId,
  env
) {
  const deviceId =
    normalizeDeviceId(
      rawDeviceId
    );

  if (!deviceId) {
    await sendMessage(
      chatId,
      env,
      "Device ID không hợp lệ."
    );
    return;
  }

  if (
    await isDeviceRevoked(
      deviceId,
      env
    )
  ) {
    await sendMessage(
      chatId,
      env,
      `🛑 ${deviceId} đã bị thu hồi vĩnh viễn.\n` +
        `Dùng /restore ${deviceId} nếu thật sự muốn cho phép ID này hoạt động lại.`
    );
    return;
  }

  const record =
    await getDeviceRecord(
      deviceId,
      env
    );

  const alias =
    await getDeviceAlias(
      deviceId,
      env
    );

  const name =
    alias ||
    `Máy ${deviceId}`;

  const group =
    normalizeDeviceGroup(
      record?.device_group
    );

  const token =
    crypto.randomUUID()
      .replace(/-/g, "")
      .slice(0, 12);

  await savePendingRevocation(
    token,
    deviceId
  );

  const details = record
    ? (
        `Tên: ${name}\n` +
        `Nhóm: ${group || "-"}\n` +
        `Heartbeat cuối: ${formatRelativeDeviceTime(record.last_seen)}`
      )
    : (
        "Hiện không có bản ghi hoạt động, " +
        "nhưng ID vẫn sẽ được đưa vào danh sách chặn."
      );

  await sendMessage(
    chatId,
    env,
    `⚠️ XÓA VĨNH VIỄN\n\n` +
      `ID: ${deviceId}\n` +
      `${details}\n\n` +
      "Sau khi xác nhận:\n" +
      "• Xóa thiết bị khỏi danh sách\n" +
      "• Chặn mọi heartbeat/report\n" +
      "• Chặn ghép nối lại cùng ID\n\n" +
      "Có thể mở lại sau bằng /restore.",
    {
      inline_keyboard: [
        [
          {
            text:
              "🗑 XÁC NHẬN XÓA",
            callback_data:
              `revoke_ok:${token}`,
          },
          {
            text: "❌ HỦY",
            callback_data:
              `revoke_cancel:${token}`,
          },
        ],
      ],
    }
  );
}

async function permanentlyRevokeDevice(
  chatId,
  rawDeviceId,
  env
) {
  const deviceId =
    normalizeDeviceId(
      rawDeviceId
    );

  if (!deviceId) {
    await sendMessage(
      chatId,
      env,
      "Device ID không hợp lệ."
    );
    return;
  }

  const existingRevocation =
    await env.DEVICE_STATUS.get(
      revokedKey(deviceId)
    );

  if (existingRevocation) {
    await sendMessage(
      chatId,
      env,
      `🛑 ${deviceId} đã bị thu hồi trước đó.`
    );
    return;
  }

  const record =
    await getDeviceRecord(
      deviceId,
      env
    );

  const alias =
    await getDeviceAlias(
      deviceId,
      env
    );

  const pairId =
    await env.DEVICE_STATUS.get(
      pairDeviceKey(deviceId)
    );

  const tombstone = {
    device_id: deviceId,
    revoked_at: Date.now(),
    last_device_group:
      normalizeDeviceGroup(
        record?.device_group
      ),
    last_seen:
      Number(record?.last_seen) ||
      null,
    last_alias:
      alias || null,
  };

  await env.DEVICE_STATUS.put(
    revokedKey(deviceId),
    JSON.stringify(tombstone)
  );

  const deletes = [
    env.DEVICE_STATUS.delete(
      deviceId
    ),
    env.DEVICE_STATUS.delete(
      `${DEVICE_ALIAS_PREFIX}${deviceId}`
    ),
    env.DEVICE_STATUS.delete(
      maintenanceKey(deviceId)
    ),
    env.DEVICE_STATUS.delete(
      healthStateKey(deviceId)
    ),
    env.DEVICE_STATUS.delete(
      pairDeviceKey(deviceId)
    ),
  ];

  if (pairId) {
    deletes.push(
      env.DEVICE_STATUS.delete(
        pairRecordKey(pairId)
      )
    );
  }

  await Promise.all(deletes);

  await setFleetDeviceRevocation(
    env,
    deviceId,
    true
  );

  await deleteKvPrefix(
    `${PAIR_RATE_PREFIX}${deviceId}:`,
    env
  );

  await env.DEVICE_STATUS.delete(
    deviceId
  );

  await sendMessage(
    chatId,
    env,
    `🗑 Đã xóa vĩnh viễn ${deviceId}.\n` +
      "Heartbeat/report và ghép nối cùng ID đã bị chặn.\n" +
      `Khôi phục khi cần: /restore ${deviceId}`
  );
}

async function restoreDevice(
  chatId,
  rawDeviceId,
  env
) {
  const deviceId =
    normalizeDeviceId(
      rawDeviceId
    );

  if (!deviceId) {
    await sendMessage(
      chatId,
      env,
      "Device ID không hợp lệ."
    );
    return;
  }

  if (
    !(await isDeviceRevoked(
      deviceId,
      env
    ))
  ) {
    await sendMessage(
      chatId,
      env,
      `${deviceId} hiện không nằm trong danh sách thu hồi.`
    );
    return;
  }

  const pairId =
    await env.DEVICE_STATUS.get(
      pairDeviceKey(deviceId)
    );

  const deletes = [
    env.DEVICE_STATUS.delete(
      deviceId
    ),
    env.DEVICE_STATUS.delete(
      `${DEVICE_ALIAS_PREFIX}${deviceId}`
    ),
    env.DEVICE_STATUS.delete(
      maintenanceKey(deviceId)
    ),
    env.DEVICE_STATUS.delete(
      healthStateKey(deviceId)
    ),
    env.DEVICE_STATUS.delete(
      pairDeviceKey(deviceId)
    ),
  ];

  if (pairId) {
    deletes.push(
      env.DEVICE_STATUS.delete(
        pairRecordKey(pairId)
      )
    );
  }

  await Promise.all(deletes);

  await setFleetDeviceRevocation(
    env,
    deviceId,
    false
  );

  await deleteKvPrefix(
    `${PAIR_RATE_PREFIX}${deviceId}:`,
    env
  );

  await env.DEVICE_STATUS.delete(
    revokedKey(deviceId)
  );

  await sendMessage(
    chatId,
    env,
    `✅ Đã cho phép lại ID ${deviceId}.\n` +
      "ID này chưa tự xuất hiện cho tới khi một Agent gửi heartbeat hoặc ghép nối lại.\n" +
      "Nếu Agent cũ vẫn còn chạy, nó cũng có thể xuất hiện lại."
  );
}

function normalizeDeviceIdList(values) {
  const rawValues = Array.isArray(values)
    ? values
    : String(values || "").split(",");

  const result = [];
  const seen = new Set();

  for (const rawValue of rawValues) {
    const deviceId = normalizeDeviceId(
      rawValue
    );

    if (!deviceId) {
      throw new Error(
        `Device ID không hợp lệ: ${rawValue}`
      );
    }

    if (seen.has(deviceId)) {
      throw new Error(
        `Device ID bị lặp: ${deviceId}`
      );
    }

    seen.add(deviceId);
    result.push(deviceId);
  }

  return result.sort(compareDeviceIds);
}

function deviceSupportsSecureSolver(record) {
  return record?.secure_solver_capable === true;
}

async function filterSecureSolverDeviceIds(deviceIds, env) {
  const result = [];
  for (const deviceId of deviceIds) {
    const record = await getDeviceRecord(deviceId, env);
    if (deviceSupportsSecureSolver(record)) result.push(deviceId);
  }
  return result;
}

function deviceSupportsSelfHeal(record) {
  return record?.self_heal_capable === true;
}

async function filterSelfHealDeviceIds(
  deviceIds,
  env
) {
  const result = [];

  for (const deviceId of deviceIds) {
    const record =
      await getDeviceRecord(
        deviceId,
        env
      );

    if (
      deviceSupportsSelfHeal(
        record
      )
    ) {
      result.push(deviceId);
    }
  }

  return result;
}

function deviceSupportsDeferredCommandQueue(
  record
) {
  return (
    record?.deferred_command_queue_capable ===
    true
  );
}

async function deferredCommandQueueReadiness(
  deviceIds,
  env
) {
  const unsupported = [];

  for (const deviceId of deviceIds) {
    const record =
      await getDeviceRecord(
        deviceId,
        env
      );

    if (
      !deviceSupportsDeferredCommandQueue(
        record
      )
    ) {
      unsupported.push(deviceId);
    }
  }

  return {
    ready: unsupported.length === 0,
    unsupported,
  };
}



async function activeDeviceIdsForTarget(
  target,
  env
) {
  const ids = await deviceIdsForTarget(
    target,
    env
  );

  const result = [];

  for (const deviceId of ids) {
    if (
      !(await isDeviceMaintenance(
        deviceId,
        env
      ))
    ) {
      result.push(deviceId);
    }
  }

  return result;
}

async function validateDirectDeviceIds(
  values,
  env
) {
  const ids = normalizeDeviceIdList(
    values
  );

  for (const deviceId of ids) {
    const record = await getDeviceRecord(
      deviceId,
      env
    );

    if (!record) {
      throw new Error(
        `${deviceId} chưa từng kết nối`
      );
    }

    if (
      await isDeviceMaintenance(
        deviceId,
        env
      )
    ) {
      throw new Error(
        `${deviceId} đang ở chế độ bảo trì`
      );
    }

    if (
      record.agent_version !==
      TARGETING_AGENT_VERSION
    ) {
      throw new Error(
        `${deviceId} chưa cập nhật Agent hỗ trợ gửi riêng. ` +
        "Hãy chạy lại msetup trên máy và chờ heartbeat."
      );
    }
  }

  return ids;
}

async function revalidateGroupDeviceIds(
  values,
  env
) {
  const ids = normalizeDeviceIdList(
    values
  );

  const result = [];

  for (const deviceId of ids) {
    const record = await getDeviceRecord(
      deviceId,
      env
    );

    if (
      record &&
      !(await isDeviceMaintenance(
        deviceId,
        env
      ))
    ) {
      result.push(deviceId);
    }
  }

  return result;
}

async function deviceDisplayName(
  deviceId,
  env
) {
  const alias = await getDeviceAlias(
    deviceId,
    env
  );

  if (
    alias &&
    alias.trim().toLowerCase() !==
      deviceId.toLowerCase()
  ) {
    return alias.trim();
  }

  return `Máy ${deviceId}`;
}

function commandEnvelope(
  commandId,
  deviceIds,
  expiresAt,
  commandLines
) {
  return [
    `# telegram_target_ids=${deviceIds.join(",")}`,
    `# telegram_expires_at=${expiresAt}`,
    `# telegram_command_id=${commandId}`,
    ...commandLines,
    "",
  ].join("\n");
}

function splitCommandEnvelopeBlocks(content) {
  const lines =
    String(content || "")
      .replace(/\r\n?/g, "\n")
      .split("\n");

  const blocks = [];
  let current = [];

  const flush = () => {
    const block =
      current.join("\n").trim();

    if (
      block &&
      /^# telegram_target_ids=/m.test(
        block
      ) &&
      /^# telegram_command_id=/m.test(
        block
      )
    ) {
      blocks.push(block);
    }

    current = [];
  };

  for (const line of lines) {
    if (
      line.startsWith(
        "# telegram_target_ids="
      )
    ) {
      flush();
      current.push(line);
      continue;
    }

    if (current.length > 0) {
      current.push(line);
    }
  }

  flush();
  return blocks;
}

function commandEnvelopeExpiresAt(block) {
  const match =
    String(block || "").match(
      /^# telegram_expires_at=(\d+)$/m
    );

  if (!match) {
    return 0;
  }

  const value = Number(match[1]);

  return Number.isFinite(value)
    ? value
    : 0;
}

function commandEnvelopeId(block) {
  const match =
    String(block || "").match(
      /^# telegram_command_id=([\w-]+)$/m
    );

  return match
    ? match[1]
    : "";
}

function mergeCommandFileContent(
  currentContent,
  newEnvelope,
  now
) {
  const incoming =
    String(newEnvelope || "").trim();

  if (!incoming) {
    throw new Error(
      "Nội dung lệnh mới trống."
    );
  }

  const incomingId =
    commandEnvelopeId(incoming);

  if (!incomingId) {
    throw new Error(
      "Lệnh mới thiếu command ID."
    );
  }

  let blocks =
    splitCommandEnvelopeBlocks(
      currentContent
    ).filter(
      (block) =>
        commandEnvelopeExpiresAt(block)
          > now &&
        commandEnvelopeId(block)
          !== incomingId
    );

  blocks.push(incoming);

  blocks = blocks.slice(
    -MAX_PENDING_COMMAND_BLOCKS
  );

  const encoder = new TextEncoder();

  let merged =
    blocks.join("\n\n").trim()
    + "\n";

  while (
    blocks.length > 1 &&
    encoder.encode(merged).length
      > MAX_PENDING_COMMAND_BYTES
  ) {
    blocks.shift();

    merged =
      blocks.join("\n\n").trim()
      + "\n";
  }

  if (
    encoder.encode(merged).length
      > MAX_PENDING_COMMAND_BYTES
  ) {
    throw new Error(
      "Hàng đợi lệnh vượt giới hạn."
    );
  }

  return merged;
}



function pendingAllocateCacheKey(token) {
  return `https://aotscript.local/pending-allocate/${token}`;
}

async function savePendingAllocate(token, spec, env) {
  const result = await fleetStateCall(env, "/aot/hub/control", {
    method: "POST",
    body: {
      protocol: AOT_HUB_PROTOCOL_VERSION,
      kind: "pending_allocate_save",
      token,
      spec
    }
  });
  if (!result.response.ok) throw new Error("Lỗi lưu trạng thái PHÂN SERVER");
}

async function loadPendingAllocate(token, env) {
  const result = await fleetStateCall(env, "/aot/hub/control", {
    method: "POST",
    body: {
      protocol: AOT_HUB_PROTOCOL_VERSION,
      kind: "pending_allocate_consume",
      token
    }
  });
  if (!result.response.ok) return null;
  return result.data.spec;
}

async function clearPendingAllocate(token, env) {
  const result = await fleetStateCall(env, "/aot/hub/control", {
    method: "POST",
    body: {
      protocol: AOT_HUB_PROTOCOL_VERSION,
      kind: "pending_allocate_clear",
      token
    }
  });
  return result.response.ok && result.data?.cleared === true;
}

function pendingDispatchCacheKey(token) {
  return (
    `https://aotscript.local/` +
    `pending-dispatch/${token}`
  );
}

async function savePendingDispatch(
  token,
  spec
) {
  await caches.default.put(
    new Request(
      pendingDispatchCacheKey(token)
    ),
    new Response(
      JSON.stringify({
        ...spec,
        created: Date.now(),
      }),
      {
        headers: {
          "Content-Type":
            "application/json",
        },
      }
    )
  );
}

async function loadPendingDispatch(token) {
  const response = await caches.default.match(
    new Request(
      pendingDispatchCacheKey(token)
    )
  );

  if (!response) return null;

  try {
    const value = JSON.parse(
      await response.text()
    );

    if (
      !value ||
      typeof value.created !== "number" ||
      Date.now() - value.created >
        COMMAND_TTL_MS
    ) {
      await clearPendingDispatch(token);
      return null;
    }

    return value;
  } catch (error) {
    await clearPendingDispatch(token);
    return null;
  }
}

async function clearPendingDispatch(token) {
  await caches.default.delete(
    new Request(
      pendingDispatchCacheKey(token)
    )
  );
}

function parseCommandKeysText(value) {
  const keys = String(value || "")
    .toLowerCase()
    .split(/[\s,]+/)
    .filter(Boolean);

  if (keys.length === 0) {
    return null;
  }

  const unique = [...new Set(keys)];

  if (
    unique.some(
      (key) => !COMMANDS[key]
    )
  ) {
    return null;
  }

  if (
    unique.includes("idle") &&
    unique.length > 1
  ) {
    return null;
  }

  return unique;
}

function orderedCommandKeys(commandKeys) {
  const selected = [
    ...new Set(commandKeys || []),
  ];

  let ordered = COMMAND_ORDER.filter(
    (key) => selected.includes(key)
  );

  if (ordered.includes("reboot")) {
    ordered = ordered.filter(
      (key) => key !== "reboot"
    );
    ordered.push("reboot");
  }

  return ordered;
}

function buildCommandLinesFromKeys(commandKeys) {
  return orderedCommandKeys(commandKeys).map((key) => {
    if (key === "update_solver") return "UPDATE_SOLVER_SECURE";
    if (key === "update_script") throw new Error("Lệnh Script cần URL.");
    return COMMANDS[key].value;
  });
}

async function resolveCommandSpec(
  spec,
  env
) {
  const commandLines = (
    Array.isArray(spec.commandLines)
      ? spec.commandLines
      : []
  )
    .map((line) => String(line).trim())
    .filter(Boolean);

  if (
    commandLines.length === 0 ||
    commandLines.length > 20 ||
    commandLines.some(
      (line) =>
        line.includes("\n") ||
        line.includes("\r") ||
        line.length > 2000
    )
  ) {
    throw new Error(
      "Nội dung lệnh không hợp lệ."
    );
  }

  const commandKeys = [
    ...new Set(
      Array.isArray(spec.commandKeys)
        ? spec.commandKeys
        : []
    ),
  ];

  if (
    commandKeys.length === 0 ||
    commandKeys.some(
      (key) => !COMMANDS[key]
    )
  ) {
    throw new Error(
      "Loại lệnh không hợp lệ."
    );
  }

  if (
    Array.isArray(spec.deviceIds) &&
    spec.deviceIds.length > 0
  ) {
    let deviceIds =
      await validateDirectDeviceIds(
        spec.deviceIds,
        env
      );

    if (commandKeys.includes("update_solver")) {
      deviceIds = await filterSecureSolverDeviceIds(deviceIds, env);
      if (deviceIds.length === 0) {
        throw new Error("Máy chưa cập nhật Agent hỗ trợ Solver bảo mật.");
      }
    }

    if (commandKeys.includes("repair")) {
      deviceIds =
        await filterSelfHealDeviceIds(
          deviceIds,
          env
        );

      if (deviceIds.length === 0) {
        throw new Error(
          "Máy chưa cập nhật Agent hỗ trợ tự sửa."
        );
      }
    }

    return {
      target: "devices",
      fileTarget: "all",
      targetLabel:
        deviceIds.length === 1
          ? await deviceDisplayName(
              deviceIds[0],
              env
            )
          : `${deviceIds.length} máy đã chọn`,
      deviceIds,
      commandKeys,
      commandLines,
    };
  }

  const target = String(
    spec.target || ""
  ).toLowerCase();

  if (!TARGET_FILES[target]) {
    throw new Error(
      "Nhóm máy không hợp lệ."
    );
  }

  let deviceIds =
    await activeDeviceIdsForTarget(
      target,
      env
    );

  if (commandKeys.includes("update_solver")) {
    deviceIds = await filterSecureSolverDeviceIds(deviceIds, env);
  }

  if (commandKeys.includes("repair")) {
    deviceIds =
      await filterSelfHealDeviceIds(
        deviceIds,
        env
      );
  }

  if (deviceIds.length === 0) {
    throw new Error(
      commandKeys.includes("update_solver")
        ? "Chưa có máy nào cập nhật Agent hỗ trợ Solver bảo mật."
        : "Không có thiết bị đủ điều kiện nhận lệnh."
    );
  }

  return {
    target,
    fileTarget: target,
    targetLabel:
      await getTargetLabel(target, env),
    deviceIds,
    commandKeys,
    commandLines,
  };
}

async function requestCommandDispatch(
  chatId,
  spec,
  env,
  options = {}
) {
  const activeRollout =
    await getActiveRollout(env);

  if (activeRollout) {
    await sendMessage(
      chatId,
      env,
      `Đang có rollout ${activeRollout.id}. ` +
        "Không gửi lệnh thường để tránh ghi đè file lệnh. " +
        "Dùng /rollout status hoặc /rollout stop."
    );
    return null;
  }

  let resolved;

  try {
    resolved = await resolveCommandSpec(
      spec,
      env
    );
  } catch (error) {
    await sendMessage(
      chatId,
      env,
      `❌ Không thể chuẩn bị lệnh: ${error.message}`
    );
    return null;
  }

  const dangerous =
    resolved.commandKeys.some(
      (key) =>
        DANGEROUS_COMMAND_KEYS.has(key)
    );

  if (
    dangerous &&
    !options.confirmed
  ) {
    const token =
      crypto.randomUUID()
        .replace(/-/g, "")
        .slice(0, 12);

    await savePendingDispatch(
      token,
      resolved
    );

    const summary =
      resolved.commandLines
        .map((line) => {
          const shortLine =
            line.length > 240
              ? line.slice(0, 237) + "..."
              : line;

          return `- ${shortLine}`;
        })
        .join("\n");

    await sendMessage(
      chatId,
      env,
      `⚠️ XÁC NHẬN LỆNH\n\n` +
        `Đích: ${resolved.targetLabel}\n` +
        `Số máy: ${resolved.deviceIds.length}\n` +
        `Lệnh:\n${summary}\n\n` +
        (
          resolved.target === "devices"
            ? "Lệnh hết hạn sau 5 phút."
            : "Tự bù 24 giờ sẽ bật khi Agent đã hỗ trợ hàng đợi."
        ),
      {
        inline_keyboard: [
          [
            {
              text: "✅ XÁC NHẬN",
              callback_data:
                `dispatch_ok:${token}`,
            },
            {
              text: "❌ HỦY",
              callback_data:
                `dispatch_cancel:${token}`,
            },
          ],
        ],
      }
    );

    return null;
  }

  try {
    return await dispatchCommandSpec(
      chatId,
      resolved,
      env
    );
  } catch (error) {
    await sendMessage(
      chatId,
      env,
      `❌ Không gửi được lệnh: ${error.message}`
    );
    return null;
  }
}

async function dispatchCommandSpec(
  chatId,
  spec,
  env
) {
  const deviceIds =
    spec.target === "devices"
      ? await validateDirectDeviceIds(
          spec.deviceIds,
          env
        )
      : await revalidateGroupDeviceIds(
          spec.deviceIds,
          env
        );

  if (deviceIds.length === 0) {
    throw new Error(
      "Không còn thiết bị đủ điều kiện nhận lệnh."
    );
  }

  const file =
    TARGET_FILES[spec.fileTarget];

  if (!file) {
    throw new Error(
      "Không xác định được file lệnh."
    );
  }

  const commandId =
    `${Date.now()}-` +
    crypto.randomUUID().slice(0, 8);

  const created = Date.now();
  const groupDispatch =
    spec.target !== "devices";

  const queueReadiness =
    await deferredCommandQueueReadiness(
      deviceIds,
      env
    );

  const queueCompatible =
    queueReadiness.ready;

  const deferred =
    groupDispatch &&
    queueCompatible;

  const expiresAt =
    created +
    (
      deferred
        ? DEFERRED_COMMAND_TTL_MS
        : COMMAND_TTL_MS
    );

  const envelope = commandEnvelope(
    commandId,
    deviceIds,
    expiresAt,
    spec.commandLines
  );

  const currentFile =
    await getGitHubFile(
      file,
      env
    );

  const currentContent =
    decodeBase64(
      currentFile.content || ""
    );

  const activeCurrentBlocks =
    splitCommandEnvelopeBlocks(
      currentContent
    ).filter(
      (block) =>
        commandEnvelopeExpiresAt(block)
          > created
    );

  const clearsGroupQueue =
    groupDispatch &&
    spec.commandKeys.includes("idle");

  if (
    !queueCompatible &&
    activeCurrentBlocks.length > 0 &&
    !clearsGroupQueue
  ) {
    throw new Error(
      "Hàng đợi đang hoạt động nhưng có máy chưa cập nhật Agent: " +
      queueReadiness.unsupported.join(", ")
    );
  }

  const content =
    clearsGroupQueue
      ? envelope
      : queueCompatible
        ? mergeCommandFileContent(
            currentContent,
            envelope,
            created
          )
        : envelope;

  const commandName =
    spec.commandKeys
      .map(
        (key) => COMMANDS[key].value
      )
      .join(" + ");

  const commit = await updateGitHubFile(
    file,
    content,
    `bot: ${spec.targetLabel} ${commandName}`,
    env,
    currentFile
  );
  try {
    await enqueueFastCommand(
      env,
      commandId,
      deviceIds,
      expiresAt,
      envelope
    );
  } catch (error) {
    console.error(
      "fast_command_enqueue_failed",
      error?.message || error
    );
  }


  let metadataStored = true;
  try {
    await storeCommandMetadata(
      env,
      commandId,
      spec.target,
      spec.commandLines,
      {
        targetLabel: spec.targetLabel,
        fileTarget: spec.fileTarget,
        deviceIds,
        commandKeys: spec.commandKeys,
        created,
        expiresAt,
      }
    );
  } catch (error) {
    metadataStored = false;
    console.error("command_metadata_store_failed", error?.message || error);
  }

  await sendMessage(
    chatId,
    env,
    `✅ Đã gửi tới ${deviceIds.length} máy\n` +
      `Đích: ${spec.targetLabel}\n` +
      `Lệnh:\n- ${spec.commandLines.join("\n- ")}\n` +
      `Hết hạn: ${deferred ? "24 giờ" : "5 phút"}\n` +
      (
        deferred
          ? "Tự bù: máy offline sẽ nhận khi online lại.\n"
          : groupDispatch
            ? `Tự bù: chưa bật vì ${queueReadiness.unsupported.length} máy chưa cập nhật Agent.\n`
            : ""
      ) +
      `Commit: ${commit.slice(0, 7)}` +
      (metadataStored ? "" : "\nTiến độ: tạm không lưu do KV hết quota."),
    {
      inline_keyboard: [
        [
          {
            text: "CẬP NHẬT TIẾN ĐỘ",
            callback_data:
              "show_progress",
          },
          {
            text: "DANH SÁCH MÁY",
            callback_data:
              "show_devices",
          },
        ],
      ],
    }
  );

  return {
    commandId,
    deviceIds,
    commit,
  };
}


async function storeCommandMetadata(
  env,
  commandId,
  target,
  commands,
  options = {}
) {
  if (
    target !== "devices" &&
    !TARGET_FILES[target]
  ) {
    throw new Error(
      `Invalid command target: ${target}`
    );
  }

  const commandList =
    Array.isArray(commands)
      ? commands.map(String)
      : [String(commands)];

  const deviceIds =
    normalizeDeviceIdList(
      options.deviceIds || []
    );

  const created =
    Number(options.created) ||
    Date.now();

  const expiresAt =
    Number(options.expiresAt) ||
    created + COMMAND_TTL_MS;

  const metadata = {
    command_id: commandId,
    target,
    target_label:
      options.targetLabel ||
      target.toUpperCase(),
    file_target:
      options.fileTarget ||
      target,
    commands: commandList,
    command_keys:
      Array.isArray(options.commandKeys)
        ? options.commandKeys
        : [],
    command_count:
      commandList.length,
    device_count:
      deviceIds.length,
    device_ids:
      deviceIds,
    created,
    expires_at:
      expiresAt,
  };

  await env.DEVICE_STATUS.put(
    `cmd:${commandId}`,
    JSON.stringify(metadata),
    {
      expirationTtl:
        COMMAND_METADATA_TTL_SECONDS,
    }
  );

  await env.DEVICE_STATUS.put(
    "latest_command",
    JSON.stringify({
      command_id: commandId,
      created,
    })
  );

  return metadata;
}



function randomBase64Url(byteLength = 32) {
  const bytes = new Uint8Array(byteLength);
  crypto.getRandomValues(bytes);

  let binary = "";

  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }

  return btoa(binary)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

async function sha256Hex(value) {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest(
    "SHA-256",
    bytes
  );

  return Array.from(
    new Uint8Array(digest),
    (byte) => byte.toString(16).padStart(2, "0")
  ).join("");
}

async function readSmallJson(request) {
  let raw;

  try {
    raw = await request.text();
  } catch (error) {
    return {
      error: "invalid_body",
    };
  }

  if (raw.length > 4096) {
    return {
      error: "body_too_large",
    };
  }

  try {
    const value = JSON.parse(raw);

    if (!value || typeof value !== "object") {
      return {
        error: "invalid_json",
      };
    }

    return {
      value,
    };
  } catch (error) {
    return {
      error: "invalid_json",
    };
  }
}

function normalizePairId(value) {
  const raw = String(value || "").trim();

  return /^[A-Za-z0-9_-]{20,40}$/.test(raw)
    ? raw
    : null;
}

function normalizePairToken(value) {
  const raw = String(value || "").trim();

  return /^[A-Za-z0-9_-]{40,100}$/.test(raw)
    ? raw
    : null;
}

function pairRecordKey(pairId) {
  return `${PAIR_PREFIX}${pairId}`;
}

function pairDeviceKey(deviceId) {
  return `${PAIR_DEVICE_PREFIX}${deviceId}`;
}

async function clearPairDeviceIndex(
  record,
  pairId,
  env
) {
  if (!record?.device_id) return;

  const key = pairDeviceKey(record.device_id);
  const current = await env.DEVICE_STATUS.get(key);

  if (current === pairId) {
    await env.DEVICE_STATUS.delete(key);
  }
}

async function handlePairRequest(
  request,
  env,
  workerOrigin
) {
  if (
    !String(env.AGENT_REPORT_SECRET || "").trim() ||
    !String(env.TELEGRAM_BOT_TOKEN || "").trim() ||
    !String(env.TELEGRAM_ADMIN_USER_ID || "").trim()
  ) {
    return noStoreJson(
      {
        ok: false,
        error: "pairing_not_configured",
      },
      503
    );
  }

  const parsed = await readSmallJson(request);

  if (parsed.error) {
    return noStoreJson(
      {
        ok: false,
        error: parsed.error,
      },
      400
    );
  }

  const purposeRaw = String(
    parsed.value.purpose || "agent"
  ).trim();
  const purpose =
    purposeRaw === "google_login"
      ? "google_login"
      : purposeRaw === "agent"
        ? "agent"
        : null;

  if (!purpose) {
    return noStoreJson(
      {
        ok: false,
        error: "invalid_pair_purpose",
      },
      400
    );
  }

  if (
    purpose === "google_login" &&
    (
      !String(env.GOOGLE_LOGIN_EMAIL || "").trim() ||
      !String(env.GOOGLE_LOGIN_PASSWORD || "")
    )
  ) {
    return noStoreJson(
      {
        ok: false,
        error: "google_login_not_configured",
      },
      503
    );
  }

  const deviceId = normalizeDeviceId(
    parsed.value.device_id
  );
  const deviceGroup = normalizeDeviceGroup(
    parsed.value.device_group
  );

  if (!deviceId) {
    return noStoreJson(
      {
        ok: false,
        error: "invalid_device_id",
      },
      400
    );
  }

  if (!deviceGroup) {
    return noStoreJson(
      {
        ok: false,
        error: "invalid_device_group",
      },
      400
    );
  }

  const legacyPrefix =
    deviceId.match(/^(MARMOT|NOVA)-/);

  if (
    legacyPrefix &&
    legacyPrefix[1] !== deviceGroup
  ) {
    return noStoreJson(
      {
        ok: false,
        error: "group_mismatch",
      },
      400
    );
  }

  if (
    await isDeviceRevoked(
      deviceId,
      env
    )
  ) {
    return noStoreJson(
      {
        ok: false,
        error: "device_revoked",
        device_id: deviceId,
      },
      410
    );
  }

  const clientIp =
    request.headers.get("CF-Connecting-IP") ||
    "unknown";

  const ipHash = (
    await sha256Hex(clientIp)
  ).slice(0, 20);

  const rateKey =
    `${PAIR_RATE_PREFIX}${purpose}:${deviceId}:${ipHash}`;

  if (await env.DEVICE_STATUS.get(rateKey)) {
    return noStoreJson(
      {
        ok: false,
        error: "pair_rate_limited",
        retry_after: PAIR_RATE_SECONDS,
      },
      429
    );
  }

  await env.DEVICE_STATUS.put(
    rateKey,
    "1",
    {
      expirationTtl: PAIR_RATE_SECONDS,
    }
  );

  const previousPairId =
    await env.DEVICE_STATUS.get(
      pairDeviceKey(deviceId)
    );

  if (previousPairId) {
    await env.DEVICE_STATUS.delete(
      pairRecordKey(previousPairId)
    );
  }

  const pairId = randomBase64Url(18);
  const pairToken = randomBase64Url(32);
  const tokenHash = await sha256Hex(pairToken);

  const randomNumber = new Uint32Array(1);
  crypto.getRandomValues(randomNumber);

  const verificationCode = String(
    randomNumber[0] % 1000000
  ).padStart(6, "0");

  const createdAt = Date.now();
  const expiresAt =
    createdAt + PAIR_TTL_SECONDS * 1000;

  if (
    await isDeviceRevoked(
      deviceId,
      env
    )
  ) {
    return noStoreJson(
      {
        ok: false,
        error: "device_revoked",
        device_id: deviceId,
      },
      410
    );
  }

  const record = {
    pair_id: pairId,
    device_id: deviceId,
    device_group: deviceGroup,
    purpose,
    verification_code: verificationCode,
    token_hash: tokenHash,
    status: "pending",
    created_at: createdAt,
    expires_at: expiresAt,
  };

  await env.DEVICE_STATUS.put(
    pairRecordKey(pairId),
    JSON.stringify(record),
    {
      expirationTtl: PAIR_TTL_SECONDS,
    }
  );

  await env.DEVICE_STATUS.put(
    pairDeviceKey(deviceId),
    pairId,
    {
      expirationTtl: PAIR_TTL_SECONDS,
    }
  );

  if (
    await isDeviceRevoked(
      deviceId,
      env
    )
  ) {
    await env.DEVICE_STATUS.delete(
      pairRecordKey(pairId)
    );
    await env.DEVICE_STATUS.delete(
      pairDeviceKey(deviceId)
    );

    return noStoreJson(
      {
        ok: false,
        error: "device_revoked",
        device_id: deviceId,
      },
      410
    );
  }

  const expiresText =
    new Date(expiresAt)
      .toISOString()
      .replace("T", " ")
      .replace("Z", " UTC");

  const requestLabel =
    purpose === "google_login"
      ? "đăng nhập Google"
      : "ghép nối Agent";

  try {
    await sendMessage(
      String(env.TELEGRAM_ADMIN_USER_ID),
      env,
      `🔐 Yêu cầu ${requestLabel}\n` +
        `Thiết bị: ${deviceId}\n` +
        `Nhóm: ${await getGroupLabel(deviceGroup, env)}\n` +
        `Mã xác minh: ${verificationCode}\n` +
        `Hết hạn: ${expiresText}\n\n` +
        "Chỉ chấp nhận nếu mã trên Termux trùng khớp.",
      {
        inline_keyboard: [
          [
            {
              text: "✅ CHẤP NHẬN",
              callback_data:
                `pair_approve:${pairId}`,
            },
            {
              text: "❌ TỪ CHỐI",
              callback_data:
                `pair_deny:${pairId}`,
            },
          ],
        ],
      }
    );
  } catch (error) {
    await env.DEVICE_STATUS.delete(
      pairRecordKey(pairId)
    );
    await env.DEVICE_STATUS.delete(
      pairDeviceKey(deviceId)
    );

    console.error(
      "pair_notification_failed",
      error?.message || error
    );

    return noStoreJson(
      {
        ok: false,
        error: "pair_notification_failed",
      },
      502
    );
  }

  return noStoreJson(
    {
      ok: true,
      status: "pending",
      purpose,
      pair_id: pairId,
      pair_token: pairToken,
      verification_code: verificationCode,
      expires_in: PAIR_TTL_SECONDS,
      poll_after: 3,
    },
    201
  );
}

async function handlePairStatus(
  request,
  env,
  workerOrigin
) {
  if (!String(env.AGENT_REPORT_SECRET || "").trim()) {
    return noStoreJson(
      {
        ok: false,
        error: "pairing_not_configured",
      },
      503
    );
  }

  const parsed = await readSmallJson(request);

  if (parsed.error) {
    return noStoreJson(
      {
        ok: false,
        error: parsed.error,
      },
      400
    );
  }

  const pairId = normalizePairId(
    parsed.value.pair_id
  );
  const pairToken = normalizePairToken(
    parsed.value.pair_token
  );

  if (!pairId || !pairToken) {
    return noStoreJson(
      {
        ok: false,
        error: "invalid_pair_credentials",
      },
      400
    );
  }

  const raw = await env.DEVICE_STATUS.get(
    pairRecordKey(pairId)
  );

  if (!raw) {
    return noStoreJson(
      {
        ok: false,
        error: "pair_not_found",
      },
      404
    );
  }

  let record;

  try {
    record = JSON.parse(raw);
  } catch (error) {
    return noStoreJson(
      {
        ok: false,
        error: "invalid_pair_record",
      },
      500
    );
  }

  const purpose =
    record.purpose === "google_login"
      ? "google_login"
      : "agent";

  const pairedDeviceId =
    normalizeDeviceId(
      record.device_id
    );

  if (
    pairedDeviceId &&
    await isDeviceRevoked(
      pairedDeviceId,
      env
    )
  ) {
    await env.DEVICE_STATUS.delete(
      pairRecordKey(pairId)
    );
    await clearPairDeviceIndex(
      record,
      pairId,
      env
    );

    return noStoreJson(
      {
        ok: false,
        error: "device_revoked",
        device_id:
          pairedDeviceId,
      },
      410
    );
  }

  const now = Date.now();

  if (
    !Number(record.expires_at) ||
    now > Number(record.expires_at)
  ) {
    await env.DEVICE_STATUS.delete(
      pairRecordKey(pairId)
    );
    await clearPairDeviceIndex(
      record,
      pairId,
      env
    );

    return noStoreJson(
      {
        ok: false,
        error: "pair_expired",
      },
      410
    );
  }

  const tokenHash = await sha256Hex(pairToken);

  if (tokenHash !== record.token_hash) {
    return noStoreJson(
      {
        ok: false,
        error: "invalid_pair_credentials",
      },
      401
    );
  }

  if (record.status === "pending") {
    return noStoreJson(
      {
        ok: true,
        status: "pending",
        purpose,
      },
      202
    );
  }

  if (record.status === "denied") {
    return noStoreJson(
      {
        ok: false,
        status: "denied",
        error: "pair_denied",
      },
      403
    );
  }

  if (record.status === "consumed") {
    return noStoreJson(
      {
        ok: false,
        status: "consumed",
        error: "pair_already_consumed",
      },
      409
    );
  }

  if (record.status !== "approved") {
    return noStoreJson(
      {
        ok: false,
        error: "invalid_pair_status",
      },
      409
    );
  }

  if (purpose === "google_login") {
    const email =
      String(env.GOOGLE_LOGIN_EMAIL || "").trim();
    const password =
      String(env.GOOGLE_LOGIN_PASSWORD || "");

    if (
      !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) ||
      !password ||
      password.length > 256
    ) {
      return noStoreJson(
        {
          ok: false,
          error: "google_login_not_configured",
        },
        503
      );
    }

    const consumedRecord = {
      ...record,
      status: "consumed",
      consumed_at: now,
    };

    delete consumedRecord.token_hash;

    await env.DEVICE_STATUS.put(
      pairRecordKey(pairId),
      JSON.stringify(consumedRecord),
      {
        expirationTtl: 60,
      }
    );

    await clearPairDeviceIndex(
      record,
      pairId,
      env
    );

    return noStoreJson({
      ok: true,
      status: "approved",
      purpose,
      google_login: {
        enabled: true,
        email,
        password,
        delete_after_success: true,
      },
    });
  }

  const consumedRecord = {
    ...record,
    status: "consumed",
    consumed_at: now,
  };

  delete consumedRecord.token_hash;

  await env.DEVICE_STATUS.put(
    pairRecordKey(pairId),
    JSON.stringify(consumedRecord),
    {
      expirationTtl: 60,
    }
  );

  await clearPairDeviceIndex(
    record,
    pairId,
    env
  );

  return noStoreJson({
    ok: true,
    status: "approved",
    purpose,
    worker_report_url:
      `${workerOrigin}/agent/report`,
    agent_report_secret:
      String(env.AGENT_REPORT_SECRET),
  });
}

async function handlePairDecision(
  pairIdValue,
  approve,
  callback,
  chatId,
  messageId,
  env,
  fromId
) {
  const pairId = normalizePairId(pairIdValue);

  if (!pairId) {
    await answerCallback(
      callback.id,
      env,
      "Yêu cầu ghép nối không hợp lệ.",
      true
    );
    return;
  }

  const key = pairRecordKey(pairId);
  const raw = await env.DEVICE_STATUS.get(key);

  if (!raw) {
    await answerCallback(
      callback.id,
      env,
      "Yêu cầu không tồn tại hoặc đã hết hạn.",
      true
    );
    return;
  }

  let record;

  try {
    record = JSON.parse(raw);
  } catch (error) {
    await answerCallback(
      callback.id,
      env,
      "Dữ liệu yêu cầu không hợp lệ.",
      true
    );
    return;
  }

  const pairedDeviceId =
    normalizeDeviceId(
      record.device_id
    );

  if (
    pairedDeviceId &&
    await isDeviceRevoked(
      pairedDeviceId,
      env
    )
  ) {
    await env.DEVICE_STATUS.delete(
      key
    );
    await clearPairDeviceIndex(
      record,
      pairId,
      env
    );

    await answerCallback(
      callback.id,
      env,
      "ID này đã bị thu hồi vĩnh viễn.",
      true
    );
    return;
  }

  const now = Date.now();

  if (
    !Number(record.expires_at) ||
    now > Number(record.expires_at)
  ) {
    await env.DEVICE_STATUS.delete(key);
    await clearPairDeviceIndex(
      record,
      pairId,
      env
    );

    await answerCallback(
      callback.id,
      env,
      "Yêu cầu đã hết hạn.",
      true
    );
    return;
  }

  if (record.status !== "pending") {
    await answerCallback(
      callback.id,
      env,
      `Yêu cầu đã ở trạng thái: ${record.status}`,
      true
    );
    return;
  }

  record.status =
    approve ? "approved" : "denied";
  record.decided_at = now;
  record.decided_by = String(fromId);

  const remainingTtl = Math.max(
    60,
    Math.ceil(
      (Number(record.expires_at) - now) / 1000
    )
  );

  await env.DEVICE_STATUS.put(
    key,
    JSON.stringify(record),
    {
      expirationTtl:
        approve ? remainingTtl : 60,
    }
  );

  if (!approve) {
    await clearPairDeviceIndex(
      record,
      pairId,
      env
    );
  }

  await answerCallback(
    callback.id,
    env,
    approve
      ? "Đã chấp nhận ghép nối."
      : "Đã từ chối ghép nối."
  );

  const statusText =
    approve
      ? "✅ ĐÃ CHẤP NHẬN"
      : "❌ ĐÃ TỪ CHỐI";

  if (messageId) {
    try {
      await editMessage(
        chatId,
        messageId,
        env,
        `${statusText} GHÉP NỐI\n` +
          `Thiết bị: ${record.device_id}\n` +
          `Nhóm: ${await getGroupLabel(record.device_group, env)}\n` +
          `Mã xác minh: ${record.verification_code}`,
        {
          inline_keyboard: [],
        }
      );
    } catch (error) {
      console.error(
        "pair_message_edit_failed",
        error?.message || error
      );
    }
  }
}

async function renameDevice(
  chatId,
  rawDeviceId,
  rawLabel,
  env
) {
  const deviceId = normalizeDeviceId(rawDeviceId);

  if (!deviceId) {
    await sendMessage(
      chatId,
      env,
      "Device ID không hợp lệ."
    );
    return;
  }

  const record = await getDeviceRecord(deviceId, env);

  if (!record) {
    await sendMessage(
      chatId,
      env,
      `Không tìm thấy thiết bị ${deviceId}.`
    );
    return;
  }

  if (String(rawLabel || "").trim() === "-") {
    await env.DEVICE_STATUS.delete(
      `${DEVICE_ALIAS_PREFIX}${deviceId}`
    );
    await sendMessage(
      chatId,
      env,
      `Đã xóa tên riêng của ${deviceId}.`
    );
    return;
  }

  const label = sanitizeLabel(rawLabel, 48);

  if (!label) {
    await sendMessage(
      chatId,
      env,
      "Tên phải từ 1 đến 48 ký tự."
    );
    return;
  }

  await env.DEVICE_STATUS.put(
    `${DEVICE_ALIAS_PREFIX}${deviceId}`,
    label
  );

  await sendMessage(
    chatId,
    env,
    `Đã đổi tên ${deviceId} thành: ${label}`
  );
}


async function deleteDevice(
  chatId,
  rawDeviceId,
  env
) {
  await requestPermanentDelete(
    chatId,
    rawDeviceId,
    env
  );
}

async function setGroupLabel(
  chatId,
  rawGroup,
  rawLabel,
  env
) {
  const group =
    normalizeGroupInput(
      rawGroup
    );

  if (!group) {
    await sendMessage(
      chatId,
      env,
      "Nhóm phải là 1 hoặc 2."
    );
    return;
  }

  const defaultLabel =
    DEFAULT_GROUP_LABELS[group];

  if (
    String(rawLabel || "")
      .trim() === "-"
  ) {
    await env.DEVICE_STATUS.delete(
      `${GROUP_LABEL_PREFIX}${group}`
    );

    await sendMessage(
      chatId,
      env,
      `Đã khôi phục tên mặc định: ${defaultLabel}.`
    );
    return;
  }

  const label =
    sanitizeLabel(
      rawLabel,
      32
    );

  if (!label) {
    await sendMessage(
      chatId,
      env,
      "Tên nhóm phải từ 1 đến 32 ký tự."
    );
    return;
  }

  await env.DEVICE_STATUS.put(
    `${GROUP_LABEL_PREFIX}${group}`,
    label
  );

  await sendMessage(
    chatId,
    env,
    `Đã đổi tên ${defaultLabel} thành: ${label}`
  );
}

function getRolloutOps() {
  return {
    targetFiles: TARGET_FILES,
    commands: COMMANDS,
    targetAgentVersion:
      TARGETING_AGENT_VERSION,
    onlineWindowMs:
      ONLINE_WINDOW_MS,
    commandTtlMs:
      COMMAND_TTL_MS,
    normalizeTargetInput,
    normalizeDeviceId,
    compareDeviceIds,
    deviceIdsForTarget,
    getDeviceRecord,
    isDeviceMaintenance,
    getTargetLabel,
    commandEnvelope,
    updateGitHubFile,
    storeCommandMetadata,
    sendMessage,
    answerCallback,
  };
}

export default {
  async fetch(request, env, ctx) {
    try {
      const url = new URL(request.url);

      if (
        request.method === "GET" &&
        url.pathname === "/aot/control/health"
      ) {
        return await handleAotControlHealth(
          request,
          env
        );
      }

      if (request.method === "POST" && url.pathname === "/aot/control/registration/discover") {
        return await handleAotRegistration(request, env, "discover");
      }
      if (request.method === "POST" && url.pathname === "/aot/control/registration/reset") {
        return await handleAotRegistration(request, env, "reset");
      }
      if (request.method === "POST" && url.pathname === "/aot/control/registration/verify") {
        return await handleAotRegistration(request, env, "verify");
      }

      if (
        request.method === "GET" &&
        url.pathname === "/aot/control/ws"
      ) {
        return await handleAotControlWebSocket(
          request,
          env,
          url
        );
      }

      if (
        request.method === "POST" &&
        url.pathname === "/aot/control/action"
      ) {
        return noStoreJson({ ok: false, error: "cross_device_control_removed" }, 410);
      }

      if (
        request.method === "POST" &&
        url.pathname === "/aot/control/ack"
      ) {
        return await handleAotControlAck(
          request,
          env
        );
      }

      if (
        request.method === "GET" &&
        url.pathname === "/agent/commands/ws"
      ) {
        return await handleAgentCommandWebSocket(
          request,
          env,
          url
        );
      }


      if (request.method === "GET" && url.pathname === "/") {
        return text("Aotscript Control Bot is online");
      }

      if (request.method === "GET" && url.pathname === "/setup") {
        const webhookUrl = `${url.origin}/telegram`;
        const result = await telegram(env, "setWebhook", {
          url: webhookUrl,
          secret_token: env.TELEGRAM_WEBHOOK_SECRET,
          allowed_updates: ["message", "callback_query"],
          drop_pending_updates: true,
        });

        await ensureNumberedGroupLabels(env);

        await telegram(env, "setMyCommands", {
          commands: [
            { command: "start", description: "Mở bảng điều khiển" },
            { command: "status", description: "Xem lệnh hiện tại" },
            { command: "devices", description: "Danh sách thiết bị" },
            { command: "health", description: "Sức khỏe toàn hệ thống" },
            { command: "alerts", description: "Cấu hình cảnh báo tự động" },
            { command: "device", description: "Chi tiết một thiết bị" },
            { command: "to", description: "Gửi lệnh tới máy cụ thể" },
            { command: "update", description: "Cập nhật canary hoặc stable" },
            { command: "batch", description: "Chạy lệnh theo lô (backup/apps)" },
            { command: "phanserver", description: "Phân bổ riêng tư (1-10 tabs)" },
            { command: "maintenance", description: "Bật hoặc tắt bảo trì" },
            { command: "rename", description: "Đổi tên thiết bị" },
            { command: "delete", description: "Thu hồi thiết bị vĩnh viễn" },
            { command: "restore", description: "Cho phép lại ID đã thu hồi" },
            { command: "groupname", description: "Đổi tên hiển thị nhóm" },
            { command: "progress", description: "Xem tiến độ lệnh gần nhất" },
            { command: "rollout", description: "Triển khai an toàn theo đợt" },
          ],
        });

        return json({ ok: true, webhook: webhookUrl, telegram: result });
      }

      
      if (request.method === "POST" && url.pathname === "/discord") {
        const signature = request.headers.get("x-signature-ed25519");
        const timestamp = request.headers.get("x-signature-timestamp");
        const body = await request.text();

        if (!signature || !timestamp || !env.DISCORD_PUBLIC_KEY) {
          return new Response("Unauthorized", { status: 401 });
        }

        const isValid = await verifyDiscordSignature(signature, timestamp, body, env.DISCORD_PUBLIC_KEY);
        if (!isValid) {
          return new Response("Invalid signature", { status: 401 });
        }

        const interaction = JSON.parse(body);
        if (interaction.type === 1) {
          return json({ type: 1 });
        }

        if (interaction.type === 2) {
          ctx.waitUntil(handleDiscordInteraction(interaction, env));
          return json({ type: 5 }); // DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE
        }

        if (interaction.type === 3) {
          ctx.waitUntil(handleDiscordComponent(interaction, env));
          return json({ type: 6 }); // DEFERRED_UPDATE_MESSAGE
        }

        return json({ error: "unknown interaction type" }, 400);
      }

      if (request.method === "POST" && url.pathname === "/telegram") {
        const webhookSecret = request.headers.get("X-Telegram-Bot-Api-Secret-Token");
        if (webhookSecret !== env.TELEGRAM_WEBHOOK_SECRET) {
          return new Response("Unauthorized", { status: 401 });
        }

        const update = await request.json();
        await handleUpdate(update, env);
        return text("ok");
      }

      if (
        request.method === "POST" &&
        url.pathname === "/agent/pair/request"
      ) {
        return await handlePairRequest(
          request,
          env,
          url.origin
        );
      }

      if (
        request.method === "POST" &&
        url.pathname === "/agent/pair/status"
      ) {
        return await handlePairStatus(
          request,
          env,
          url.origin
        );
      }

      if (request.method === "GET" && url.pathname === "/agent/solver-url") {
        return await handleSecureSolverUrl(request, env);
      }

      // Agent report endpoint
      if (request.method === "POST" && url.pathname === "/agent/report") {
        return await handleAgentReport(request, env);
      }

      return new Response("Not found", { status: 404 });
    } catch (error) {
      console.error(error);
      return json({ ok: false, error: String(error?.message || error) }, 500);
    }
  },

  async scheduled(_controller, env, ctx) {
    ctx.waitUntil(
      Promise.all([
        ensureNumberedGroupLabels(env),
        checkFleetHealth(env),
        checkActiveRollout(
          env,
          getRolloutOps()
        ),
      ])
    );
  },
};

async function resolveAndValidateTelegramTargets(targetStr, env) {
  if (!targetStr || !targetStr.trim()) {
    throw new Error("Target không được để trống.");
  }
  const rawTarget = targetStr.trim();
  const wantedGroup = normalizeDeviceGroup(rawTarget);
  
  const stateResult = await fleetStateCall(env, "/aot/hub/state");
  if (!stateResult.response.ok) {
     throw new Error("Không thể lấy trạng thái thiết bị.");
  }
  const durableRecords = stateResult.data?.state?.devices || [];
  
  if (wantedGroup) {
    const ids = [];
    for (const record of durableRecords) {
      if (normalizeDeviceGroup(record?.device_group) === wantedGroup) {
        if (!record.online) {
           throw new Error(`Thiết bị ${record?.device_id} trong nhóm ${wantedGroup} đang OFFLINE.`);
        }
        ids.push(normalizeDeviceId(record?.device_id));
      }
    }
    if (ids.length === 0) {
      throw new Error(`Nhóm ${wantedGroup} không có thiết bị nào.`);
    }
    return ids.sort(compareDeviceIds);
  }
  
  const ids = normalizeDeviceIdList(rawTarget);
  if (ids.length === 0) {
     throw new Error("Danh sách target không hợp lệ.");
  }
  
  const onlineIds = new Set();
  const allIds = new Set();
  for (const record of durableRecords) {
    const did = normalizeDeviceId(record?.device_id);
    if (!did) continue;
    allIds.add(did);
    if (record.online) onlineIds.add(did);
  }
  
  for (const id of ids) {
    if (!allIds.has(id)) {
      throw new Error(`Thiết bị ${id} không tồn tại.`);
    }
    if (!onlineIds.has(id)) {
      throw new Error(`Thiết bị ${id} đang OFFLINE.`);
    }
  }
  return ids;
}
async function handleUpdate(update, env) {
  const message = update.message;
  const callback = update.callback_query;
  const from = message?.from || callback?.from;
  const chatId = message?.chat?.id || callback?.message?.chat?.id;
  const messageId = callback?.message?.message_id;

  if (!from || !chatId) return;

  if (String(from.id) !== String(env.TELEGRAM_ADMIN_USER_ID)) {
    if (callback) {
      await telegram(env, "answerCallbackQuery", {
        callback_query_id: callback.id,
        text: "Không có quyền sử dụng bot.",
        show_alert: true,
      });
    }
    return;
  }

  if (callback) {
    await handleCallback(callback, chatId, messageId, env, from.id);
    return;
  }

  const input = (message.text || message.caption || "").trim();

  if (input === "/start" || input === "/menu") {
    await showTargets(chatId, env);
    return;
  }

  if (input === "/status") {
    await sendStatus(chatId, env);
    return;
  }


  if (input.match(/^\/phanserver(?:\s|$)/)) {
    const parts = input.split(/\s+/);
    if (parts.length !== 3) {
      await telegram(env, "sendMessage", {
        chat_id: chatId,
        text: "Cú pháp: /phanserver <device1,device2...> <tabs>"
      });
      return;
    }
    const targetStr = parts[1];
    const tabs = Number(parts[2]);
    if (!Number.isInteger(tabs) || tabs < 1 || tabs > 10 || parts[2] !== String(tabs)) {
      await telegram(env, "sendMessage", {
        chat_id: chatId,
        text: "Số tab phải từ 1 đến 10."
      });
      return;
    }
    try {
      const ids = await resolveAndValidateTelegramTargets(targetStr, env);
      
      const abortCtrl = new AbortController();
      const abortTimeout = setTimeout(() => abortCtrl.abort(), 10000);
      let fileData;
      try {
        fileData = await getGitHubFile("tong_hop_link.txt", env, { signal: abortCtrl.signal });
      } finally {
        clearTimeout(abortTimeout);
      }
      const text = decodeBase64(fileData?.content || "");
      
      const allocationMap = parseTongHopLink(text, ids, tabs);
      
      const token = crypto.randomUUID().replace(/-/g, "").slice(0, 12);
      await savePendingAllocate(token, { ids, tabs, allocationMap }, env);
      
      let textMsg = "<b>PREVIEW PHÂN SERVER</b>\n\n";
      for (const [id, list] of Object.entries(allocationMap)) {
        textMsg += `<b>${id}</b>\n`;
        textMsg += list.map(x => `${x.pkg}: ${x.url}`).join("\n") + "\n\n";
      }
      textMsg += "Xác nhận chạy phân server?";
      if (textMsg.length > 4000) {
         let cutPoint = textMsg.lastIndexOf("\n", 4000);
         if (cutPoint === -1) cutPoint = 4000;
         textMsg = textMsg.slice(0, cutPoint) + "\n\n(Đã cắt bớt)\nXác nhận chạy phân server?";
      }
      
      await telegram(env, "sendMessage", {
        chat_id: chatId,
        text: textMsg,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "✅ Confirm", callback_data: `allocate_ok:${token}` },
              { text: "❌ Cancel", callback_data: `allocate_cancel:${token}` }
            ]
          ]
        }
      });
    } catch (error) {
      await telegram(env, "sendMessage", {
        chat_id: chatId,
        text: "Lỗi: " + String(error.message || error)
      });
    }
    return;
  }

  if (input === "/devices") {
    await showDevices(chatId, env);
    return;
  }

  if (input === "/health") {
    await showHealth(
      chatId,
      env
    );
    return;
  }

  const alertsMatch =
    input.match(
      /^\/alerts(?:\s+(on|off|status))?$/i
    );

  if (alertsMatch) {
    const requested =
      String(
        alertsMatch[1] || "status"
      ).toLowerCase();

    await configureAlerts(
      chatId,
      requested === "on"
        ? true
        : requested === "off"
          ? false
          : null,
      env
    );
    return;
  }

  if (
    await handleRolloutCommand({
      input,
      chatId,
      env,
      ops: getRolloutOps(),
    })
  ) {
    return;
  }

  const deviceMatch =
    input.match(
      /^\/device\s+(\S+)$/i
    );

  if (deviceMatch) {
    await showDeviceDetail(
      chatId,
      deviceMatch[1],
      env
    );
    return;
  }

  const maintenanceMatch =
    input.match(
      /^\/maintenance\s+(\S+)\s+(on|off)$/i
    );

  if (maintenanceMatch) {
    await changeDeviceMaintenance(
      chatId,
      maintenanceMatch[1],
      maintenanceMatch[2]
        .toLowerCase() === "on",
      env
    );
    return;
  }

  const directSolverMatch =
    input.match(
      /^\/to\s+([A-Za-z0-9_,-]+)\s+solver(?:\s+(https?:\/\/\S+))?$/i
    );

  if (directSolverMatch) {
    if (directSolverMatch[2]) {
      await sendMessage(
        chatId,
        env,
        "Không gửi URL Solver qua Telegram. Dùng: /to m116 solver"
      );
      return;
    }
    await requestCommandDispatch(
      chatId,
      {
        deviceIds: directSolverMatch[1].split(","),
        commandKeys: ["update_solver"],
        commandLines: ["UPDATE_SOLVER_SECURE"],
      },
      env
    );
    return;
  }

  const directScriptMatch =
    input.match(
      /^\/to\s+([A-Za-z0-9_,-]+)\s+script\s+(https?:\/\/\S+)$/i
    );

  if (directScriptMatch) {
    const url = directScriptMatch[2];

    if (!isValidUrl(url)) {
      await sendMessage(
        chatId,
        env,
        "URL Script không hợp lệ."
      );
      return;
    }

    await requestCommandDispatch(
      chatId,
      {
        deviceIds:
          directScriptMatch[1].split(","),
        commandKeys:
          ["update_script"],
        commandLines:
          [`Updatescript ${url}`],
      },
      env
    );
    return;
  }

  const directMatch =
    input.match(
      /^\/to\s+([A-Za-z0-9_,-]+)\s+(.+)$/i
    );

  if (directMatch) {
    const commandKeys =
      parseCommandKeysText(
        directMatch[2]
      );

    if (
      !commandKeys ||
      commandKeys.includes(
        "update_solver"
      ) ||
      commandKeys.includes(
        "update_script"
      )
    ) {
      await sendMessage(
        chatId,
        env,
        "Cú pháp không hợp lệ.\n" +
          "Ví dụ: /to m166 idle\n" +
          "Nhiều máy: /to m166,m167 reboot\n" +
          "Solver: /to m166 solver\n" +
          "Script: /to m166 script https://..."
      );
      return;
    }

    let commandLines;

    try {
      commandLines =
        buildCommandLinesFromKeys(
          commandKeys
        );
    } catch (error) {
      await sendMessage(
        chatId,
        env,
        `❌ ${error.message}`
      );
      return;
    }

    await requestCommandDispatch(
      chatId,
      {
        deviceIds:
          directMatch[1].split(","),
        commandKeys,
        commandLines,
      },
      env
    );
    return;
  }

  const renameMatch =
    input.match(/^\/rename\s+(\S+)\s+(.+)$/i);

  if (renameMatch) {
    await renameDevice(
      chatId,
      renameMatch[1],
      renameMatch[2],
      env
    );
    return;
  }

  const deleteMatch =
    input.match(/^\/delete\s+(\S+)$/i);

  if (deleteMatch) {
    await deleteDevice(
      chatId,
      deleteMatch[1],
      env
    );
    return;
  }

  const restoreMatch =
    input.match(
      /^\/restore\s+(\S+)$/i
    );

  if (restoreMatch) {
    await restoreDevice(
      chatId,
      restoreMatch[1],
      env
    );
    return;
  }

  const groupNameMatch =
    input.match(/^\/groupname\s+(\S+)\s+(.+)$/i);

  if (groupNameMatch) {
    await setGroupLabel(
      chatId,
      groupNameMatch[1],
      groupNameMatch[2],
      env
    );
    return;
  }

  if (input === "/progress") {
    await sendProgress(chatId, env);
    return;
  }

  const updateCmdMatch = input.match(/^\/update(?:\s+(.*))?$/i);
  if (updateCmdMatch) {
    const argsMatch = (updateCmdMatch[1] || "").match(/^(canary|stable)\s+([A-Za-z0-9_,-]+)$/i);
    if (!argsMatch) {
      await sendMessage(chatId, env, "Sử dụng: /update canary|stable <m123|m123,m124|MARMOT>");
      return;
    }
    const channel = argsMatch[1].toLowerCase();
    
    try {
      const resolvedTarget = await resolveAndValidateTelegramTargets(argsMatch[2], env);
      const body = {
        protocol: AOT_HUB_PROTOCOL_VERSION,
        kind: `update_${channel}`,
        target_device_ids: resolvedTarget,
      };
      const result = await fleetStateCall(env, "/aot/hub/control", { method: "POST", body });
      if (result.response.ok) {
        await sendMessage(chatId, env, `Lệnh update_${channel} đã được gửi thành công tới ${resolvedTarget.join(",")}.`);
      } else {
        const errorType = result.data?.error || result.response.status;
        const msg = result.data?.message
          ? `: ${String(result.data.message).replace(/Bearer\s+[A-Za-z0-9_.-]+/gi, "Bearer [REDACTED]").replace(/ghp_[A-Za-z0-9]+/gi, "[REDACTED]")}`
          : "";
        await sendMessage(chatId, env, `Lỗi: ${errorType}${msg}`);
      }
    } catch (e) {
      await sendMessage(chatId, env, `Lỗi: ${e.message}`);
    }
    return;
  }

  const batchCmdMatch = input.match(/^\/batch(?:\s+(.*))?$/i);
  if (batchCmdMatch) {
    const argsMatch = (batchCmdMatch[1] || "").match(/^(backup|apps|restore_data)\s+([A-Za-z0-9_,-]+)$/i);
    if (!argsMatch) {
      await sendMessage(chatId, env, "Sử dụng: /batch backup|apps|restore_data <m123|m123,m124|MARMOT>");
      return;
    }
    const actionMap = {
      "backup": "open_swift_backup",
      "apps": "open_swift_apps",
      "restore_data": "backup_restore_data"
    };
    const kind = actionMap[argsMatch[1].toLowerCase()];
    
    try {
      const resolvedTarget = await resolveAndValidateTelegramTargets(argsMatch[2], env);
      const body = {
        protocol: AOT_HUB_PROTOCOL_VERSION,
        kind: kind,
        target_device_ids: resolvedTarget,
      };
      const result = await fleetStateCall(env, "/aot/hub/control", { method: "POST", body });
      if (result.response.ok) {
        await sendMessage(chatId, env, `Lệnh ${kind} đã được gửi thành công tới ${resolvedTarget.join(",")}.`);
      } else {
        await sendMessage(chatId, env, `Lỗi: ${result.data?.error || result.response.status}`);
      }
    } catch (e) {
      await sendMessage(chatId, env, `Lỗi: ${e.message}`);
    }
    return;
  }

  const pendingState = await loadSessionState(from.id, chatId);
  if (pendingState && pendingState.step && !input.startsWith("/")) {
    await handlePendingSessionMessage(chatId, from.id, pendingState, input, env);
    return;
  }

  // Solver dùng Cloudflare secret; không nhận URL qua Telegram.
  if (/^\/solver\b.*https?:\/\//i.test(input)) {
    await sendMessage(
      chatId,
      env,
      "Không gửi URL Solver qua Telegram. Dùng /solver all, /solver marmot hoặc /solver nova."
    );
    return;
  }

  const solverMatch = input.match(/^\/solver\s+(all|marmot|nova)$/i);
  if (solverMatch) {
    await executeSolverCommand(chatId, solverMatch[1].toLowerCase(), null, env);
    return;
  }

  const scriptMatch = input.match(/^\/script\s+(all|marmot|nova)\s+(https?:\/\/\S+)$/i);
  if (scriptMatch) {
    const target = scriptMatch[1].toLowerCase();
    const url = scriptMatch[2];
    if (!TARGET_FILES[target]) {
      await sendMessage(chatId, env, "Target không hợp lệ cho /script.");
      return;
    }
    if (!isValidUrl(url)) {
      await sendMessage(chatId, env, "URL không hợp lệ. Phải là http:// hoặc https://");
      return;
    }
    await executeScriptCommand(chatId, target, url, env);
    return;
  }

  if (input === "/solver") {
    await promptTargetSelection(chatId, "solver", "", env);
    return;
  }

  const scriptShortMatch = input.match(/^\/script\s+(https?:\/\/\S+)$/i);
  if (scriptShortMatch) {
    const url = scriptShortMatch[1];
    if (!isValidUrl(url)) {
      await sendMessage(chatId, env, "URL không hợp lệ. Phải là http:// hoặc https://");
      return;
    }
    await promptTargetSelection(chatId, "script", url, env);
    return;
  }

  const parsed = parseTextCommand(input);
  if (!parsed) {
    await sendMessage(
      chatId,
      env,
      "Lệnh không hợp lệ. Dùng /start để mở bảng điều khiển hoặc /status để xem trạng thái."
    );
    return;
  }

  await executeCommands(chatId, parsed.target, parsed.commandKeys, env);
}

function parseTextCommand(input) {
  const match =
    String(input || "").match(
      /^\/(\S+)\s+(.+)$/i
    );

  if (!match) {
    return null;
  }

  const target =
    normalizeTargetInput(
      match[1]
    );

  if (
    !target ||
    !TARGET_FILES[target]
  ) {
    return null;
  }

  const commandKeys =
    match[2]
      .toLowerCase()
      .split(/[\s,]+/)
      .filter(Boolean);

  if (commandKeys.length === 0) {
    return null;
  }

  const allowed =
    new Set(
      Object.keys(COMMANDS)
    );

  const filtered =
    commandKeys.filter(
      (key) =>
        allowed.has(key)
    );

  if (
    filtered.length === 0 ||
    filtered.some(
      (key) => !COMMANDS[key]
    )
  ) {
    return null;
  }

  const uniqueKeys =
    [...new Set(filtered)];

  if (
    uniqueKeys.includes("idle") &&
    uniqueKeys.length > 1
  ) {
    return null;
  }

  return {
    target,
    commandKeys: uniqueKeys,
  };
}

async function promptTargetSelection(chatId, command, url, env) {
  const token = crypto.randomUUID().slice(0, 8);
  await saveShortCommand(token, command, url);

  const title = command === "solver" ? "/solver" : "/script";
  const marmotLabel = await getGroupLabel("MARMOT", env);
  const novaLabel = await getGroupLabel("NOVA", env);

  const replyMarkup = {
    inline_keyboard: [
      [
        {
          text: "🌍 TẤT CẢ",
          callback_data: `shortcmd:${command}:${token}:all`,
        },
        {
          text: `1️⃣ ${marmotLabel}`,
          callback_data: `shortcmd:${command}:${token}:marmot`,
        },
      ],
      [
        {
          text: `2️⃣ ${novaLabel}`,
          callback_data: `shortcmd:${command}:${token}:nova`,
        },
        {
          text: "❌ HỦY",
          callback_data: `cancel:${token}`,
        },
      ],
    ],
  };

  await sendMessage(
    chatId,
    env,
    `Chọn nhóm để gửi ${title} ${url}`,
    replyMarkup
  );
}

async function saveShortCommand(token, command, url) {
  const key = shortCommandCacheKey(token);
  const value = JSON.stringify({ command, url, created: Date.now() });
  await caches.default.put(
    new Request(key),
    new Response(value, { headers: { "Content-Type": "application/json" } })
  );
}

async function loadShortCommand(token) {
  const key = shortCommandCacheKey(token);
  const response = await caches.default.match(new Request(key));
  if (!response) return null;
  try {
    const stored = JSON.parse(await response.text());
    if (!stored || typeof stored.created !== "number") {
      await clearShortCommand(token);
      return null;
    }
    const age = Date.now() - stored.created;
    if (age > 5 * 60 * 1000) {
      await clearShortCommand(token);
      return null;
    }
    return stored;
  } catch (error) {
    await clearShortCommand(token);
    return null;
  }
}

async function clearShortCommand(token) {
  const key = shortCommandCacheKey(token);
  await caches.default.delete(new Request(key));
}

function shortCommandCacheKey(token) {
  return `https://aotscript.local/shortcmd/${token}`;
}

function sessionStateKey(userId, chatId) {
  return `https://aotscript.local/session/${userId}:${chatId}`;
}

async function saveSessionState(userId, chatId, state, env) {
  const key = sessionStateKey(userId, chatId);
  const body = JSON.stringify({ ...state, created: Date.now() });
  await caches.default.put(
    new Request(key),
    new Response(body, { headers: { "Content-Type": "application/json" } })
  );
}

async function loadSessionState(userId, chatId) {
  const key = sessionStateKey(userId, chatId);
  const response = await caches.default.match(new Request(key));
  if (!response) return null;
  try {
    const stored = JSON.parse(await response.text());
    if (!stored || typeof stored.created !== "number") {
      await clearSessionState(userId, chatId);
      return null;
    }
    if (Date.now() - stored.created > 10 * 60 * 1000) {
      await clearSessionState(userId, chatId);
      return null;
    }
    return stored;
  } catch (error) {
    await clearSessionState(userId, chatId);
    return null;
  }
}

async function clearSessionState(userId, chatId) {
  const key = sessionStateKey(userId, chatId);
  await caches.default.delete(new Request(key));
}

async function startUrlSession(chatId, userId, target, commandKeys, env) {
  const state = {
    userId,
    chatId,
    target,
    commandKeys,
    step: "awaiting_script_url",
    solverUrl: commandKeys.includes("update_solver") ? "Cloudflare secret" : null,
    scriptUrl: null,
  };
  if (!commandKeys.includes("update_script")) {
    await executeCommands(chatId, target, commandKeys, env);
    return;
  }
  await saveSessionState(userId, chatId, state, env);
  await sendMessage(
    chatId,
    env,
    "Vui lòng gửi URL Script (http:// hoặc https://) hoặc bấm HỦY.",
    { inline_keyboard: [[{ text: "❌ HỦY", callback_data: "cancel-session" }]] }
  );
}

async function handlePendingSessionMessage(chatId, userId, state, input, env) {
  const lower = input.trim();
  if (state.step === "awaiting_solver_url") {
    if (!isValidUrl(lower)) {
      await sendMessage(chatId, env, "URL Solver không hợp lệ. Phải bắt đầu bằng http:// hoặc https://. Vui lòng gửi lại hoặc bấm HỦY.");
      return;
    }
    state.solverUrl = lower;
    if (state.commandKeys.includes("update_script")) {
      state.step = "awaiting_script_url";
      await saveSessionState(userId, chatId, state, env);
      await sendMessage(chatId, env, "Vui lòng gửi URL Script (http:// hoặc https://) hoặc bấm HỦY.", {
        inline_keyboard: [[{ text: "❌ HỦY", callback_data: "cancel-session" }]],
      });
      return;
    }
  } else if (state.step === "awaiting_script_url") {
    if (!isValidUrl(lower)) {
      await sendMessage(chatId, env, "URL Script không hợp lệ. Phải bắt đầu bằng http:// hoặc https://. Vui lòng gửi lại hoặc bấm HỦY.");
      return;
    }
    state.scriptUrl = lower;
  } else {
    await sendMessage(chatId, env, "Phiên hiện tại không hợp lệ. Vui lòng bấm /start để bắt đầu lại.");
    return;
  }

  await saveSessionState(userId, chatId, state, env);

  if (state.commandKeys.includes("update_solver") && !state.solverUrl) {
    return;
  }
  if (state.commandKeys.includes("update_script") && !state.scriptUrl) {
    return;
  }

  await sendSessionSummary(chatId, state, env);
}

async function sendSessionSummary(chatId, state, env) {
  const lines = [`Nhóm: ${state.target.toUpperCase()}`, "Lệnh:"];
  for (const key of state.commandKeys) {
    if (key === "update_solver") {
      lines.push(`- ${COMMANDS[key].value}: ${state.solverUrl}`);
    } else if (key === "update_script") {
      lines.push(`- ${COMMANDS[key].value}: ${state.scriptUrl}`);
    } else {
      lines.push(`- ${COMMANDS[key].value}`);
    }
  }
  lines.push("\nNhấn XÁC NHẬN GỬI để tiếp tục hoặc HỦY để dừng.");
  const replyMarkup = {
    inline_keyboard: [
      [{ text: "✅ XÁC NHẬN GỬI", callback_data: "confirm-session" }],
      [{ text: "❌ HỦY", callback_data: "cancel-session" }],
    ],
  };
  await sendMessage(chatId, env, lines.join("\n"), replyMarkup);
}


async function executeSessionCommands(
  chatId,
  state,
  env
) {
  try {
    const commandLines =
      orderedCommandKeys(
        state.commandKeys
      ).map((key) => {
        if (key === "update_solver") {
          return "UPDATE_SOLVER_SECURE";
        }

        if (key === "update_script") {
          if (
            !isValidUrl(
              state.scriptUrl
            )
          ) {
            throw new Error(
              "URL Script không hợp lệ."
            );
          }

          return `Updatescript ${state.scriptUrl}`;
        }

        return COMMANDS[key].value;
      });

    await requestCommandDispatch(
      chatId,
      {
        target: state.target,
        commandKeys:
          state.commandKeys,
        commandLines,
      },
      env,
      {
        confirmed: true,
      }
    );
  } catch (error) {
    await sendMessage(
      chatId,
      env,
      `❌ Không gửi được lệnh: ${error.message}`
    );
  } finally {
    await clearSessionState(
      state.userId,
      state.chatId
    );
  }
}

async function handleCallback(callback, chatId, messageId, env, fromId) {
  const data = callback.data || "";

  if (
    await handleRolloutCallback({
      data,
      callbackId: callback.id,
      chatId,
      env,
      ops: getRolloutOps(),
    })
  ) {
    return;
  }

  if (data === "show_health") {
    await answerCallback(
      callback.id,
      env
    );

    await showHealth(
      chatId,
      env,
      messageId
    );
    return;
  }

  if (data === "health_offline") {
    await answerCallback(
      callback.id,
      env
    );

    await showHealthList(
      chatId,
      "offline",
      env
    );
    return;
  }

  if (data === "health_issues") {
    await answerCallback(
      callback.id,
      env
    );

    await showHealthList(
      chatId,
      "issues",
      env
    );
    return;
  }

  if (data === "health_agent") {
    await answerCallback(
      callback.id,
      env
    );

    await showHealthList(
      chatId,
      "agent",
      env
    );
    return;
  }

  if (data === "alerts_status") {
    await answerCallback(
      callback.id,
      env
    );

    await configureAlerts(
      chatId,
      null,
      env
    );
    return;
  }

  if (
    data.startsWith(
      "revoke_ok:"
    )
  ) {
    const token = data.slice(
      "revoke_ok:".length
    );

    const pending =
      await loadPendingRevocation(
        token
      );

    if (!pending) {
      await answerCallback(
        callback.id,
        env,
        "Xác nhận đã hết hạn.",
        true
      );
      return;
    }

    await clearPendingRevocation(
      token
    );

    await answerCallback(
      callback.id,
      env,
      "Đang thu hồi thiết bị..."
    );

    await permanentlyRevokeDevice(
      chatId,
      pending.device_id,
      env
    );
    return;
  }

  if (
    data.startsWith(
      "revoke_cancel:"
    )
  ) {
    await clearPendingRevocation(
      data.slice(
        "revoke_cancel:".length
      )
    );

    await answerCallback(
      callback.id,
      env,
      "Đã hủy xóa thiết bị."
    );
    return;
  }


  if (data.startsWith("allocate_cancel:")) {
    const token = data.slice("allocate_cancel:".length);
    const cleared = await clearPendingAllocate(token, env);
    if (cleared) {
      await answerCallback(callback.id, env, "Đã hủy PHÂN SERVER.");
    } else {
      await answerCallback(callback.id, env, "Lệnh đã được xác nhận/đang xử lý, không thể hủy.", true);
    }
    return;
  }

  if (data.startsWith("allocate_ok:")) {
    const token = data.slice("allocate_ok:".length);
    const pending = await loadPendingAllocate(token, env);
    if (!pending) {
      await answerCallback(callback.id, env, "Xác nhận đã hết hạn hoặc đã được xử lý.", true);
      return;
    }
    await answerCallback(callback.id, env, "Đang chạy phân server...");
    
    try {
      const stateResult = await fleetStateCall(env, "/aot/hub/state");
      if (!stateResult.response.ok) {
        throw new Error("Không thể lấy trạng thái thiết bị để xác nhận lại.");
      }
      const durableRecords = stateResult.data?.state?.devices || [];
      const onlineMap = new Map();
      for (const r of durableRecords) {
        onlineMap.set(normalizeDeviceId(r.device_id), r.online);
      }
      for (const id of pending.ids) {
        if (!onlineMap.get(id)) {
          throw new Error(`Thiết bị ${id} đã ngắt kết nối (OFFLINE). Lệnh bị hủy.`);
        }
      }

      const result = await fleetStateCall(env, "/aot/hub/control", {
        method: "POST",
        body: {
          protocol: AOT_HUB_PROTOCOL_VERSION,
          kind: "allocate_server",
          target_device_ids: pending.ids,
          allocationMap: pending.allocationMap,
          telegram_chat_id: chatId
        }
      });
      if (!result.response.ok) {
        if (result.data?.error === "offline_devices_in_allocate_batch") {
          throw new Error("Có thiết bị ngắt kết nối trong lúc xác nhận. Lệnh phân server đã bị hủy toàn bộ.");
        }
        throw new Error(JSON.stringify(result.data));
      }
      const actionId = result.data.batch.action_id;
      
      await telegram(env, "editMessageText", {
        chat_id: chatId,
        message_id: callback.message.message_id,
        text: "Đã gửi lệnh phân server, đang chờ thiết bị phản hồi..."
      });
    } catch (e) {
      await telegram(env, "sendMessage", {
        chat_id: chatId,
        text: "Lỗi chạy phân server: " + String(e.message || e)
      });
    }
    return;
  }

  if (
    data.startsWith(
      "dispatch_ok:"
    )
  ) {
    const token = data.slice(
      "dispatch_ok:".length
    );

    const pending =
      await loadPendingDispatch(
        token
      );

    if (!pending) {
      await answerCallback(
        callback.id,
        env,
        "Xác nhận đã hết hạn.",
        true
      );
      return;
    }

    await clearPendingDispatch(token);

    await answerCallback(
      callback.id,
      env,
      "Đang gửi lệnh..."
    );

    await requestCommandDispatch(
      chatId,
      pending,
      env,
      {
        confirmed: true,
      }
    );
    return;
  }

  if (
    data.startsWith(
      "dispatch_cancel:"
    )
  ) {
    await clearPendingDispatch(
      data.slice(
        "dispatch_cancel:".length
      )
    );

    await answerCallback(
      callback.id,
      env,
      "Đã hủy."
    );
    return;
  }

  if (
    data.startsWith(
      "devicecmd:"
    )
  ) {
    await answerCallback(
      callback.id,
      env
    );

    await showDeviceCommands(
      chatId,
      data.slice(
        "devicecmd:".length
      ),
      0,
      env,
      messageId
    );
    return;
  }


  if (
    data.startsWith(
      "reload_novagag2:"
    )
  ) {
    const deviceId =
      normalizeDeviceId(
        data.slice(
          "reload_novagag2:"
            .length
        )
      );

    if (!deviceId) {
      await answerCallback(
        callback.id,
        env,
        "Device ID không hợp lệ.",
        true
      );
      return;
    }

    const record =
      await getDeviceRecord(
        deviceId,
        env
      );

    if (!record) {
      await answerCallback(
        callback.id,
        env,
        "Không tìm thấy thiết bị.",
        true
      );
      return;
    }

    if (
      normalizeDeviceGroup(
        record.device_group
      ) !== "NOVA"
    ) {
      await answerCallback(
        callback.id,
        env,
        "Novagag2 chỉ dành cho NHÓM 2.",
        true
      );
      return;
    }

    if (
      record
        .reload_novagag2_capable !==
        true
    ) {
      await answerCallback(
        callback.id,
        env,
        "Máy chưa cập nhật Agent hỗ trợ lệnh này.",
        true
      );
      return;
    }

    if (
      Date.now() -
        Number(
          record.last_seen || 0
        ) >
        ONLINE_WINDOW_MS
    ) {
      await answerCallback(
        callback.id,
        env,
        "Máy đang offline.",
        true
      );
      return;
    }

    if (
      await isDeviceMaintenance(
        deviceId,
        env
      )
    ) {
      await answerCallback(
        callback.id,
        env,
        "Máy đang bảo trì.",
        true
      );
      return;
    }

    await answerCallback(
      callback.id,
      env,
      "Đang gửi lệnh nạp lại..."
    );

    const dispatched =
      await requestCommandDispatch(
        chatId,
        {
          deviceIds: [
            deviceId,
          ],
          commandKeys: [
            "reload_novagag2",
          ],
          commandLines: [
            "RELOAD_NOVAGAG2",
          ],
        },
        env
      );

    if (dispatched) {
      await sendMessage(
        chatId,
        env,
        "Sau khi tiến độ báo thành công, hãy đóng hẳn Roblox/Delta rồi mở lại."
      );
    }

    return;
  }

  if (data.startsWith("dpick:")) {
    const parts = data.split(":");
    const deviceId =
      normalizeDeviceId(parts[1]);
    const mask = Number(parts[2]);
    const commandKey = parts[3];

    if (
      !deviceId ||
      !Number.isInteger(mask) ||
      !COMMANDS[commandKey]
    ) {
      await answerCallback(
        callback.id,
        env,
        "Lựa chọn không hợp lệ.",
        true
      );
      return;
    }

    await answerCallback(
      callback.id,
      env
    );

    await showDeviceCommands(
      chatId,
      deviceId,
      toggleCommand(
        mask,
        commandKey
      ),
      env,
      messageId
    );
    return;
  }

  if (data.startsWith("dsend:")) {
    const parts = data.split(":");
    const deviceId =
      normalizeDeviceId(parts[1]);
    const mask = Number(parts[2]);
    const commandKeys =
      commandKeysFromMask(mask);

    if (
      !deviceId ||
      commandKeys.length === 0
    ) {
      await answerCallback(
        callback.id,
        env,
        "Bạn chưa chọn lệnh.",
        true
      );
      return;
    }

    if (commandKeys.includes("update_script")) {
      await answerCallback(
        callback.id,
        env,
        "Dùng lệnh /to để nhập URL Script.",
        true
      );
      return;
    }

    let commandLines;

    try {
      commandLines =
        buildCommandLinesFromKeys(
          commandKeys
        );
    } catch (error) {
      await answerCallback(
        callback.id,
        env,
        error.message,
        true
      );
      return;
    }

    await answerCallback(
      callback.id,
      env,
      "Đang chuẩn bị lệnh..."
    );

    await requestCommandDispatch(
      chatId,
      {
        deviceIds: [deviceId],
        commandKeys,
        commandLines,
      },
      env
    );
    return;
  }

  if (
    data.startsWith(
      "maintenance_toggle:"
    )
  ) {
    const deviceId =
      normalizeDeviceId(
        data.slice(
          "maintenance_toggle:".length
        )
      );

    if (!deviceId) {
      await answerCallback(
        callback.id,
        env,
        "Device ID không hợp lệ.",
        true
      );
      return;
    }

    const enabled =
      !(await isDeviceMaintenance(
        deviceId,
        env
      ));

    await answerCallback(
      callback.id,
      env
    );

    await changeDeviceMaintenance(
      chatId,
      deviceId,
      enabled,
      env,
      {
        silent: true,
      }
    );

    await showDeviceDetail(
      chatId,
      deviceId,
      env,
      messageId
    );
    return;
  }

  if (data.startsWith("device:")) {
    await answerCallback(
      callback.id,
      env
    );

    await showDeviceDetail(
      chatId,
      data.slice(
        "device:".length
      ),
      env,
      messageId
    );
    return;
  }

  if (data.startsWith("pair_approve:")) {
    await handlePairDecision(
      data.slice("pair_approve:".length),
      true,
      callback,
      chatId,
      messageId,
      env,
      fromId
    );
    return;
  }

  if (data.startsWith("pair_deny:")) {
    await handlePairDecision(
      data.slice("pair_deny:".length),
      false,
      callback,
      chatId,
      messageId,
      env,
      fromId
    );
    return;
  }

  if (data.startsWith("target:")) {
    const target = data.slice(7);
    if (!TARGET_FILES[target]) {
      await answerCallback(callback.id, env, "Nhóm không hợp lệ.", true);
      return;
    }

    await answerCallback(callback.id, env);
    await showCommands(chatId, target, 0, env, messageId);
    return;
  }

  if (data.startsWith("pick:")) {
    const [, target, maskText, commandKey] = data.split(":");
    const mask = Number(maskText);

    if (!TARGET_FILES[target] || !Number.isInteger(mask) || !COMMANDS[commandKey]) {
      await answerCallback(callback.id, env, "Lựa chọn không hợp lệ.", true);
      return;
    }

    const nextMask = toggleCommand(mask, commandKey);
    await answerCallback(callback.id, env);
    await showCommands(chatId, target, nextMask, env, messageId);
    return;
  }

  if (data.startsWith("send:")) {
    const [, target, maskText] = data.split(":");
    const mask = Number(maskText);
    const commandKeys = commandKeysFromMask(mask);

    if (!TARGET_FILES[target] || commandKeys.length === 0) {
      await answerCallback(callback.id, env, "Bạn chưa chọn lệnh nào.", true);
      return;
    }

    if (commandKeys.includes("update_script")) {
      await answerCallback(callback.id, env);
      await startUrlSession(chatId, fromId, target, commandKeys, env);
      return;
    }


    await answerCallback(callback.id, env, "Đang gửi lệnh...");
    await executeCommands(chatId, target, commandKeys, env);
    return;
  }

  if (data.startsWith("confirm:")) {
    const [, target, maskText] = data.split(":");
    const mask = Number(maskText);
    const commandKeys = commandKeysFromMask(mask);
    if (!TARGET_FILES[target] || commandKeys.length === 0) {
      await answerCallback(callback.id, env, "Không tìm thấy lệnh để gửi.", true);
      return;
    }
    await answerCallback(callback.id, env, "Đang gửi lệnh...");
    await executeCommands(chatId, target, commandKeys, env);
    return;
  }

  if (data === "confirm-session") {
    await answerCallback(callback.id, env, "Đang gửi lệnh...");
    const state = await loadSessionState(fromId, chatId);
    if (!state || !state.commandKeys || !state.target) {
      await answerCallback(callback.id, env, "Phiên đã hết hạn hoặc không hợp lệ.", true);
      return;
    }
    await executeSessionCommands(chatId, state, env);
    return;
  }

  if (data === "cancel-session") {
    await clearSessionState(fromId, chatId);
    await answerCallback(callback.id, env, "Đã hủy.");
    return;
  }

  if (data.startsWith("cancel:")) {
    const parts = data.split(":");
    if (parts.length === 2) {
      const token = parts[1];
      await clearShortCommand(token);
      await answerCallback(callback.id, env, "Đã hủy.");
      return;
    }
    await answerCallback(callback.id, env, "Đã hủy.");
    return;
  }

  if (data.startsWith("clear:")) {
    const target = data.slice(6);
    if (!TARGET_FILES[target]) {
      await answerCallback(callback.id, env, "Nhóm không hợp lệ.", true);
      return;
    }

    await answerCallback(callback.id, env, "Đã bỏ chọn.");
    await showCommands(chatId, target, 0, env, messageId);
    return;
  }

  if (data.startsWith("shortcmd:")) {
    const parts = data.split(":");
    if (parts.length !== 4) {
      await answerCallback(callback.id, env, "Dữ liệu không hợp lệ.", true);
      return;
    }
    const [, command, token, target] = parts;
    if (!["solver", "script"].includes(command) || !TARGET_FILES[target]) {
      await answerCallback(callback.id, env, "Lựa chọn không hợp lệ.", true);
      return;
    }

    const stored = await loadShortCommand(token);
    if (!stored || stored.command !== command) {
      await answerCallback(callback.id, env, "Lệnh đã hết hạn. Vui lòng thử lại.", true);
      return;
    }

    await answerCallback(callback.id, env);
    await clearShortCommand(token);
    if (command === "solver") {
      await executeSolverCommand(chatId, target, stored.url, env);
      return;
    }
    await executeScriptCommand(chatId, target, stored.url, env);
    return;
  }

  if (data === "status") {
    await answerCallback(callback.id, env);
    await sendStatus(chatId, env);
    return;
  }

  if (data === "menu") {
    await answerCallback(callback.id, env);
    await showTargets(chatId, env, messageId);
    return;
  }

  if (data === "show_devices") {
    await answerCallback(callback.id, env);
    await showDevices(chatId, env);
    return;
  }

  if (data === "show_progress") {
    await answerCallback(callback.id, env);
    await sendProgress(chatId, env);
    return;
  }

  await answerCallback(callback.id, env, "Nút không hợp lệ.", true);
}

function toggleCommand(mask, commandKey) {
  const command = COMMANDS[commandKey];

  if (commandKey === "idle") {
    return mask === command.bit ? 0 : command.bit;
  }

  const maskWithoutIdle = mask & ~COMMANDS.idle.bit;
  return maskWithoutIdle ^ command.bit;
}

function commandKeysFromMask(mask) {
  if (!Number.isInteger(mask) || mask <= 0) return [];

  if (mask & COMMANDS.idle.bit) {
    return ["idle"];
  }

  return COMMAND_ORDER.filter(
    (key) => key !== "idle" && (mask & COMMANDS[key].bit) !== 0
  );
}



async function showTargets(
  chatId,
  env,
  messageId
) {
  const marmotLabel =
    await getGroupLabel(
      "MARMOT",
      env
    );

  const novaLabel =
    await getGroupLabel(
      "NOVA",
      env
    );

  const textValue =
    "Chọn nhóm, thiết bị hoặc chức năng quản lý:";

  const replyMarkup = {
    inline_keyboard: [
      [
        {
          text: "🌍 TẤT CẢ",
          callback_data:
            "target:all",
        },
        {
          text: `1️⃣ ${marmotLabel}`,
          callback_data:
            "target:marmot",
        },
      ],
      [
        {
          text: `2️⃣ ${novaLabel}`,
          callback_data:
            "target:nova",
        },
        {
          text: "🎯 TỪNG MÁY",
          callback_data:
            "show_devices",
        },
      ],
      [
        {
          text: "🚀 TRIỂN KHAI",
          callback_data:
            "show_rollout",
        },
      ],
      [
        {
          text: "🏥 SỨC KHỎE",
          callback_data:
            "show_health",
        },
        {
          text: "📊 TIẾN ĐỘ",
          callback_data:
            "show_progress",
        },
      ],
      [
        {
          text: "📋 TRẠNG THÁI",
          callback_data:
            "status",
        },
        {
          text: "🔔 CẢNH BÁO",
          callback_data:
            "alerts_status",
        },
      ],
    ],
  };

  if (messageId) {
    await editMessage(
      chatId,
      messageId,
      env,
      textValue,
      replyMarkup
    );
  } else {
    await sendMessage(
      chatId,
      env,
      textValue,
      replyMarkup
    );
  }
}

async function showCommands(chatId, target, mask, env, messageId) {
  const label = await getTargetLabel(target, env);
  const selected = commandKeysFromMask(mask);
  const selectedText = selected.length
    ? selected.map((key) => COMMANDS[key].value).join(", ")
    : "Chưa chọn";

  const button = (key) => ({
    text: `${mask & COMMANDS[key].bit ? "✅" : "⬜"} ${COMMANDS[key].label}`,
    callback_data: `pick:${target}:${mask}:${key}`,
  });

  const textValue =
    `Nhóm đã chọn: ${label}\n` +
    `Đã chọn: ${selectedText}\n\n` +
    "Chạm để chọn/bỏ chọn, sau đó bấm GỬI LỆNH.";

  const replyMarkup = {
    inline_keyboard: [
      [button("idle"), button("setup_vip")],
      [button("install_track"), button("setup_boot")],
      [button("setup_caylapbu"), button("run_caylapbu")],
      [button("update_delta"), button("update_solver")],
      [button("update_script"), button("reboot")],
      [
        {
          text: `✅ GỬI ${selected.length} LỆNH`,
          callback_data: `send:${target}:${mask}`,
        },
        { text: "🗑 BỎ CHỌN", callback_data: `clear:${target}` },
      ],
      [
        { text: "⬅️ Đổi nhóm", callback_data: "menu" },
        { text: "📋 Trạng thái", callback_data: "status" },
      ],
    ],
  };

  if (messageId) {
    await editMessage(chatId, messageId, env, textValue, replyMarkup);
  } else {
    await sendMessage(chatId, env, textValue, replyMarkup);
  }
}


async function executeCommands(
  chatId,
  target,
  commandKeys,
  env,
  options = {}
) {
  if (
    !TARGET_FILES[target] ||
    !Array.isArray(commandKeys) ||
    commandKeys.length === 0
  ) {
    await sendMessage(
      chatId,
      env,
      "Target hoặc lệnh không hợp lệ."
    );
    return;
  }

  let commandLines;

  try {
    commandLines =
      buildCommandLinesFromKeys(
        commandKeys
      );
  } catch (error) {
    await sendMessage(
      chatId,
      env,
      `❌ ${error.message}`
    );
    return;
  }

  await requestCommandDispatch(
    chatId,
    {
      target,
      commandKeys,
      commandLines,
    },
    env,
    options
  );
}

async function sendStatus(chatId, env) {
  const lines = [
    "📋 Lệnh hiện tại trên GitHub:",
  ];

  for (
    const [target, file]
    of Object.entries(TARGET_FILES)
  ) {
    const label =
      await getTargetLabel(
        target,
        env
      );

    try {
      const data =
        await getGitHubFile(
          file,
          env
        );

      const content =
        decodeBase64(
          data.content || ""
        ).trim() || "(trống)";

      lines.push(
        `\n${label} — ${file}\n${content}`
      );
    } catch (error) {
      lines.push(
        `\n${label} — lỗi: ${error.message}`
      );
    }
  }

  await sendMessage(
    chatId,
    env,
    lines.join("\n")
  );
}

async function getGitHubFile(path, env, options = {}) {
  const response = await fetch(
    `https://api.github.com/repos/${OWNER}/${REPO}/contents/${encodeURIComponent(path)}?ref=${BRANCH}`,
    {
      headers: githubHeaders(env),
      signal: options?.signal,
    }
  );

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.message || `GitHub GET ${response.status}`);
  }
  return data;
}

async function updateGitHubFile(
  path,
  content,
  message,
  env,
  currentFile = null
) {
  const current =
    currentFile ||
    await getGitHubFile(
      path,
      env
    );
  const response = await fetch(
    `https://api.github.com/repos/${OWNER}/${REPO}/contents/${encodeURIComponent(path)}`,
    {
      method: "PUT",
      headers: githubHeaders(env),
      body: JSON.stringify({
        message,
        content: encodeBase64(content),
        sha: current.sha,
        branch: BRANCH,
      }),
    }
  );

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.message || `GitHub PUT ${response.status}`);
  }
  return data.commit.sha;
}

function githubHeaders(env) {
  return {
    Accept: "application/vnd.github+json",
    Authorization: `Bearer ${env.GITHUB_TOKEN}`,
    "X-GitHub-Api-Version": "2026-03-10",
    "User-Agent": "aotscript-cloudflare-worker",
    "Content-Type": "application/json",
  };
}

function isValidUrl(u) {
  try {
    const parsed = new URL(u);
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch (e) {
    return false;
  }
}


async function executeSolverCommand(chatId, target, _url, env) {
  await requestCommandDispatch(
    chatId,
    {
      target,
      commandKeys: ["update_solver"],
      commandLines: ["UPDATE_SOLVER_SECURE"],
    },
    env
  );
}

async function executeScriptCommand(
  chatId,
  target,
  url,
  env
) {
  await requestCommandDispatch(
    chatId,
    {
      target,
      commandKeys:
        ["update_script"],
      commandLines:
        [`Updatescript ${url}`],
    },
    env
  );
}

function convertToDiscordComponents(replyMarkup) {
  if (!replyMarkup || !replyMarkup.inline_keyboard) return undefined;
  const components = [];
  for (const row of replyMarkup.inline_keyboard) {
    const actionRow = { type: 1, components: [] };
    for (const btn of row) {
      actionRow.components.push({
        type: 2,
        label: String(btn.text || "Button").substring(0, 80),
        style: 1,
        custom_id: String(btn.callback_data || "btn").substring(0, 100)
      });
    }
    components.push(actionRow);
  }
  return components;
}

async function sendMessage(chatId, env, textValue, replyMarkup) {
  if (String(chatId).startsWith("discord:")) {
    const [, appId, token] = String(chatId).split(":");
    let content = String(textValue || "");
    if (content.length > 2000) content = content.substring(0, 1997) + "...";
    const payload = { content };
    const comps = convertToDiscordComponents(replyMarkup);
    if (comps && comps.length > 0) payload.components = comps;
    const discordUrl = `https://discord.com/api/v10/webhooks/${appId}/${token}`;
    await fetch(discordUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    return;
  }
  return telegram(env, "sendMessage", {
    chat_id: chatId,
    text: textValue,
    reply_markup: replyMarkup,
  });
}

async function editMessage(chatId, messageId, env, textValue, replyMarkup) {
  if (String(chatId).startsWith("discord:")) {
    const [, appId, token] = String(chatId).split(":");
    let content = String(textValue || "");
    if (content.length > 2000) content = content.substring(0, 1997) + "...";
    const payload = { content };
    const comps = convertToDiscordComponents(replyMarkup);
    if (comps && comps.length > 0) payload.components = comps;
    // For Discord, we just edit the original response
    const discordUrl = `https://discord.com/api/v10/webhooks/${appId}/${token}/messages/@original`;
    await fetch(discordUrl, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    return;
  }
  return telegram(env, "editMessageText", {
    chat_id: chatId,
    message_id: messageId,
    text: textValue,
    reply_markup: replyMarkup,
  });
}

async function answerCallback(callbackQueryId, env, textValue, showAlert = false) {
  if (String(callbackQueryId).startsWith("discord:")) {
    if (!textValue) return;
    const [, appId, token] = String(callbackQueryId).split(":");
    let content = String(textValue || "");
    if (content.length > 2000) content = content.substring(0, 1997) + "...";
    const discordUrl = `https://discord.com/api/v10/webhooks/${appId}/${token}`;
    await fetch(discordUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content })
    });
    return;
  }
  return telegram(env, "answerCallbackQuery", {
    callback_query_id: callbackQueryId,
    ...(textValue ? { text: textValue, show_alert: showAlert } : {}),
  });
}

async function telegram(env, method, payload) {
  const response = await fetch(
    `https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/${method}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }
  );

  const data = await response.json();
  if (!response.ok || !data.ok) {
    throw new Error(data.description || `Telegram ${response.status}`);
  }
  return data.result;
}

function encodeBase64(value) {
  const bytes = new TextEncoder().encode(value);
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

function decodeBase64(value) {
  const clean = value.replace(/\n/g, "");
  const binary = atob(clean);
  const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

// -------------------- Agent reporting and device helpers --------------------



function isAuthorizedAgentRequest(request, env) {
  const expected = String(env.AGENT_REPORT_SECRET || "");
  const provided = String(request.headers.get("X-Agent-Secret") || "");
  return expected.length > 0 && provided === expected;
}

async function handleSecureSolverUrl(request, env) {
  if (!isAuthorizedAgentRequest(request, env)) {
    return new Response("Unauthorized", { status: 401 });
  }
  const solverUrl = String(env.SOLVER_UPDATE_URL || "").trim();
  if (!isValidUrl(solverUrl)) {
    return noStoreJson({ ok: false, error: "solver_not_configured" }, 503);
  }
  return noStoreJson({ ok: true, solver_url: solverUrl });
}

async function handleAgentReport(request, env) {
  const secret =
    request.headers.get(
      "X-Agent-Secret"
    );
  if (
    !secret ||
    secret !==
      env.AGENT_REPORT_SECRET
  ) {
    return new Response(
      "Unauthorized",
      { status: 401 }
    );
  }
  let body;
  try {
    body = await request.json();
  } catch (error) {
    return json(
      {
        ok: false,
        error: "invalid_json",
      },
      400
    );
  }
  const {
    device_id:
      reportedDeviceId,
    device_group:
      reportedDeviceGroup,
    timestamp,
    status,
    command_id,
    command,
    command_index,
    command_total,
    last_result,
  } = body;
  if (
    !reportedDeviceId ||
    !reportedDeviceGroup ||
    !timestamp ||
    !status
  ) {
    return json(
      {
        ok: false,
        error: "missing_fields",
      },
      400
    );
  }
  if (
    !ALLOWED_REPORT_STATUSES
      .includes(status)
  ) {
    return json(
      {
        ok: false,
        error: "invalid_status",
      },
      400
    );
  }
  const deviceId =
    normalizeDeviceId(
      reportedDeviceId
    );
  const deviceGroup =
    normalizeDeviceGroup(
      reportedDeviceGroup
    );
  if (!deviceId) {
    return json(
      {
        ok: false,
        error:
          "invalid_device_id",
      },
      400
    );
  }
  if (!deviceGroup) {
    return json(
      {
        ok: false,
        error:
          "invalid_device_group",
      },
      400
    );
  }
  const legacyPrefix =
    deviceId.match(
      /^(MARMOT|NOVA)-/
    );
  if (
    legacyPrefix &&
    legacyPrefix[1] !==
      deviceGroup
  ) {
    return json(
      {
        ok: false,
        error:
          "group_mismatch",
      },
      400
    );
  }
  const payload = {
    device_id: deviceId,
    device_group: deviceGroup,
    timestamp,
    status,
  };
  if (command_id) {
    payload.command_id =
      command_id;
    payload.command =
      command ?? null;
    payload.command_index =
      command_index ?? null;
    payload.command_total =
      command_total ?? null;
  }
  if (last_result) {
    payload.last_result =
      String(last_result)
        .slice(0, 500);
  }
  const batteryNumber =
    Number(body.battery_level);
  if (
    Number.isFinite(
      batteryNumber
    ) &&
    batteryNumber >= 0 &&
    batteryNumber <= 100
  ) {
    payload.battery_level =
      Math.round(
        batteryNumber
      );
  }
  if (
    typeof body.charging ===
      "boolean"
  ) {
    payload.charging =
      body.charging;
  }
  const androidLabel =
    sanitizeLabel(
      body.android_version,
      32
    );
  if (androidLabel) {
    payload.android_version =
      androidLabel;
  }
  const agentLabel =
    sanitizeLabel(
      body.agent_version,
      64
    );
  if (agentLabel) {
    payload.agent_version =
      agentLabel;
  }

  if (
    typeof body
      .reload_novagag2_capable ===
      "boolean"
  ) {
    payload
      .reload_novagag2_capable =
      body
        .reload_novagag2_capable;
  }

  if (typeof body.secure_solver_capable === "boolean") {
    payload.secure_solver_capable = body.secure_solver_capable;
  } else if (status === "heartbeat") {
    payload.secure_solver_capable = false;
  }

  if (
    typeof body.self_heal_capable ===
      "boolean"
  ) {
    payload.self_heal_capable =
      body.self_heal_capable;
  } else if (
    status === "heartbeat"
  ) {
    payload.self_heal_capable = false;
  }

  if (
    typeof body.deferred_command_queue_capable ===
      "boolean"
  ) {
    payload.deferred_command_queue_capable =
      body.deferred_command_queue_capable;
  } else if (
    status === "heartbeat"
  ) {
    payload.deferred_command_queue_capable = false;
  }

  const uptimeNumber =
    Number(body.uptime_seconds);
  if (
    Number.isFinite(
      uptimeNumber
    ) &&
    uptimeNumber >= 0
  ) {
    payload.uptime_seconds =
      Math.floor(
        uptimeNumber
      );
  }
  const storageNumber =
    Number(
      body.storage_free_bytes
    );
  if (
    Number.isFinite(
      storageNumber
    ) &&
    storageNumber >= 0
  ) {
    payload.storage_free_bytes =
      Math.floor(
        storageNumber
      );
  }
  try {
    const result =
      await reportFleetDevice(
        env,
        payload
      );
    if (
      result.response.status ===
        410
    ) {
      return noStoreJson(
        {
          ok: false,
          error:
            "device_revoked",
          device_id: deviceId,
        },
        410
      );
    }
    if (!result.response.ok) {
      return noStoreJson(
        {
          ok: false,
          error:
            result.data?.error ||
            "fleet_state_failed",
        },
        result.response.status
      );
    }
    return noStoreJson({
      ok: true,
      device_id: deviceId,
      device_group:
        deviceGroup,
    });
  } catch (error) {
    console.error(
      "agent_report_failed",
      error?.message || error
    );
    return noStoreJson(
      {
        ok: false,
        error:
          String(
            error?.message ||
            error
          ),
      },
      500
    );
  }
}



async function getDeviceRecord(
  deviceId,
  env
) {
  try {
    const normalized =
      normalizeDeviceId(
        deviceId
      );
    if (!normalized) {
      return null;
    }
    if (
      await isDeviceRevoked(
        normalized,
        env
      )
    ) {
      return null;
    }
    try {
      const durableRecord =
        await getFleetDeviceRecord(
          env,
          normalized
        );
      if (durableRecord) {
        return durableRecord;
      }
    } catch (error) {
      console.error(
        "fleet_state_read_failed",
        error?.message || error
      );
    }
    const raw =
      await env.DEVICE_STATUS.get(
        normalized
      );
    if (!raw) return null;
    const record =
      JSON.parse(raw);
    return (
      record &&
      typeof record ===
        "object"
    )
      ? record
      : null;
  } catch (error) {
    return null;
  }
}

function formatTimestamp(ms) {
  try {
    return new Date(ms).toISOString().replace('T',' ').replace('Z',' UTC');
  } catch (e) {
    return '-';
  }
}

function formatRelativeDeviceTime(ms, now = Date.now()) {
  const timestamp = Number(ms);

  if (!Number.isFinite(timestamp) || timestamp <= 0) {
    return "chưa rõ";
  }

  const elapsed = Math.max(0, now - timestamp);

  if (elapsed < 15 * 1000) {
    return "vừa xong";
  }

  if (elapsed < 60 * 1000) {
    return `${Math.floor(elapsed / 1000)} giây trước`;
  }

  if (elapsed < 60 * 60 * 1000) {
    return `${Math.floor(elapsed / (60 * 1000))} phút trước`;
  }

  if (elapsed < 24 * 60 * 60 * 1000) {
    return `${Math.floor(elapsed / (60 * 60 * 1000))} giờ trước`;
  }

  if (elapsed < 7 * 24 * 60 * 60 * 1000) {
    return `${Math.floor(elapsed / (24 * 60 * 60 * 1000))} ngày trước`;
  }

  try {
    return new Intl.DateTimeFormat(
      "vi-VN",
      {
        timeZone: "Asia/Ho_Chi_Minh",
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      }
    ).format(new Date(timestamp));
  } catch (error) {
    return "chưa rõ";
  }
}

function deviceStatusLabel(record, online) {
  if (!online) {
    return "Mất kết nối";
  }

  const status =
    record?.last_status ||
    record?.last_report_status ||
    "heartbeat";

  switch (status) {
    case "received":
      return "Đã nhận lệnh";

    case "running":
      return "Đang chạy lệnh";

    case "success":
      return "Đã hoàn tất lệnh";

    case "error":
      return "Có lỗi";

    case "expired":
      return "Lệnh đã hết hạn";

    case "heartbeat":
    default:
      return "Đang kết nối";
  }
}



function formatByteCount(value) {
  const bytes = Number(value);

  if (
    !Number.isFinite(bytes) ||
    bytes < 0
  ) {
    return "chưa rõ";
  }

  if (bytes >= 1024 ** 3) {
    return (
      `${(bytes / 1024 ** 3).toFixed(1)} GB`
    );
  }

  if (bytes >= 1024 ** 2) {
    return (
      `${(bytes / 1024 ** 2).toFixed(0)} MB`
    );
  }

  return `${Math.round(bytes / 1024)} KB`;
}

function formatUptimeSeconds(value) {
  const seconds = Number(value);

  if (
    !Number.isFinite(seconds) ||
    seconds < 0
  ) {
    return "chưa rõ";
  }

  const days =
    Math.floor(seconds / 86400);

  const hours =
    Math.floor(
      (seconds % 86400) / 3600
    );

  const minutes =
    Math.floor(
      (seconds % 3600) / 60
    );

  const parts = [];

  if (days > 0) {
    parts.push(`${days} ngày`);
  }

  if (hours > 0) {
    parts.push(`${hours} giờ`);
  }

  parts.push(`${minutes} phút`);

  return parts.join(" ");
}

async function changeDeviceMaintenance(
  chatId,
  rawDeviceId,
  enabled,
  env,
  options = {}
) {
  const deviceId =
    normalizeDeviceId(rawDeviceId);

  if (!deviceId) {
    await sendMessage(
      chatId,
      env,
      "Device ID không hợp lệ."
    );
    return false;
  }

  const record =
    await getDeviceRecord(
      deviceId,
      env
    );

  if (!record) {
    await sendMessage(
      chatId,
      env,
      `Không tìm thấy ${deviceId}.`
    );
    return false;
  }

  if (
    record.agent_version !==
    TARGETING_AGENT_VERSION
  ) {
    await sendMessage(
      chatId,
      env,
      `${deviceId} chưa cập nhật Agent hỗ trợ bảo trì. ` +
      "Hãy chạy lại msetup và chờ heartbeat."
    );
    return false;
  }

  await setDeviceMaintenance(
    deviceId,
    enabled,
    env
  );

  if (!options.silent) {
    await sendMessage(
      chatId,
      env,
      enabled
        ? `🛠 Đã bật bảo trì cho ${deviceId}.`
        : `✅ Đã tắt bảo trì cho ${deviceId}.`
    );
  }

  return true;
}

async function showDeviceDetail(
  chatId,
  rawDeviceId,
  env,
  messageId
) {
  const deviceId =
    normalizeDeviceId(rawDeviceId);

  if (!deviceId) {
    await sendMessage(
      chatId,
      env,
      "Device ID không hợp lệ."
    );
    return;
  }

  const record =
    await getDeviceRecord(
      deviceId,
      env
    );

  if (!record) {
    await sendMessage(
      chatId,
      env,
      `Không tìm thấy ${deviceId}.`
    );
    return;
  }

  const now = Date.now();

  const online =
    now - Number(
      record.last_seen || 0
    ) <= ONLINE_WINDOW_MS;

  const maintenance =
    await isDeviceMaintenance(
      deviceId,
      env
    );

  const name =
    await deviceDisplayName(
      deviceId,
      env
    );

  const groupLabel =
    await getGroupLabel(
      record.device_group,
      env
    );

  const batteryNumber =
    Number(record.battery_level);

  const battery =
    Number.isFinite(batteryNumber)
      ? `${batteryNumber}%`
      : "chưa rõ";

  const charging =
    record.charging === true
      ? " — đang sạc"
      : record.charging === false
        ? " — không sạc"
        : "";

  const compatible =
    record.agent_version ===
    TARGETING_AGENT_VERSION;

  const resultText =
    String(
      record.last_result ||
      "Không có"
    ).slice(0, 180);

  const textValue =
    `${online ? "🟢" : "⚪"} ${name}\n` +
    `ID: ${deviceId}\n` +
    `Nhóm: ${groupLabel}\n` +
    `Chế độ: ${maintenance ? "🛠 Bảo trì" : "Hoạt động"}\n` +
    `Kết nối: ${online ? "Đang online" : "Mất kết nối"}\n` +
    `Hoạt động: ${formatRelativeDeviceTime(record.last_seen, now)}\n\n` +
    `Pin: ${battery}${charging}\n` +
    `Android: ${record.android_version || "chưa rõ"}\n` +
    `Agent: ${record.agent_version || "bản cũ"}\n` +
    `Gửi riêng: ${compatible ? "Sẵn sàng" : "Chưa cập nhật"}\n` +
    `Uptime: ${formatUptimeSeconds(record.uptime_seconds)}\n` +
    `Bộ nhớ trống: ${formatByteCount(record.storage_free_bytes)}\n\n` +
    `Lệnh cuối: ${record.last_command || "-"}\n` +
    `Trạng thái: ${deviceStatusLabel(record, online)}\n` +
    `Kết quả: ${resultText}`;

  const replyMarkup = {
    inline_keyboard: [
      [
        {
          text: "🎯 GỬI LỆNH",
          callback_data:
            `devicecmd:${deviceId}`,
        },
        {
          text: maintenance
            ? "✅ TẮT BẢO TRÌ"
            : "🛠 BẬT BẢO TRÌ",
          callback_data:
            `maintenance_toggle:${deviceId}`,
        },
      ],
      [
        {
          text: "⬅️ DANH SÁCH",
          callback_data:
            "show_devices",
        },
      ],
    ],
  };

  if (messageId) {
    await editMessage(
      chatId,
      messageId,
      env,
      textValue,
      replyMarkup
    );
  } else {
    await sendMessage(
      chatId,
      env,
      textValue,
      replyMarkup
    );
  }
}


async function showDeviceCommands(
  chatId,
  rawDeviceId,
  mask,
  env,
  messageId
) {
  const deviceId =
    normalizeDeviceId(rawDeviceId);

  const record =
    deviceId
      ? await getDeviceRecord(
          deviceId,
          env
        )
      : null;

  if (!deviceId || !record) {
    await sendMessage(
      chatId,
      env,
      "Không tìm thấy thiết bị."
    );
    return;
  }

  if (
    record.agent_version !==
    TARGETING_AGENT_VERSION
  ) {
    await sendMessage(
      chatId,
      env,
      `${deviceId} chưa cập nhật Agent hỗ trợ gửi riêng.`
    );
    return;
  }

  if (
    await isDeviceMaintenance(
      deviceId,
      env
    )
  ) {
    await sendMessage(
      chatId,
      env,
      `${deviceId} đang bảo trì nên không nhận lệnh mới.`
    );
    return;
  }

  const name =
    await deviceDisplayName(
      deviceId,
      env
    );

  const selected =
    commandKeysFromMask(mask);

  const button = (key) => ({
    text:
      `${mask & COMMANDS[key].bit ? "✅" : "⬜"} ` +
      `${COMMANDS[key].label}`,
    callback_data:
      `dpick:${deviceId}:${mask}:${key}`,
  });

  const canReloadNovagag2 =
    normalizeDeviceGroup(
      record.device_group
    ) === "NOVA" &&
    record
      .reload_novagag2_capable ===
      true;

  const textValue =
    `Máy đã chọn: ${name}\n` +
    `ID: ${deviceId}\n` +
    `Đã chọn: ${
      selected.length
        ? selected
            .map(
              (key) =>
                COMMANDS[key].value
            )
            .join(", ")
        : "Chưa chọn"
    }`;

  const rows = [
    [
      button("idle"),
      button("setup_vip"),
    ],
    [
      button("install_track"),
      button("setup_boot"),
    ],
    [
      button("setup_caylapbu"),
      button("run_caylapbu"),
    ],
    [
      button("update_delta"),
      button("reboot"),
    ],
    [
      button("update_solver"),
      button("update_script"),
    ],
  ];

  if (canReloadNovagag2) {
    rows.push([
      {
        text:
          "🔄 NẠP LẠI NOVAGAG2",
        callback_data:
          `reload_novagag2:${deviceId}`,
      },
    ]);
  }

  rows.push(
    [
      {
        text:
          `✅ GỬI ${selected.length} LỆNH`,
        callback_data:
          `dsend:${deviceId}:${mask}`,
      },
    ],
    [
      {
        text:
          "⬅️ CHI TIẾT MÁY",
        callback_data:
          `device:${deviceId}`,
      },
    ]
  );

  const replyMarkup = {
    inline_keyboard: rows,
  };

  if (messageId) {
    await editMessage(
      chatId,
      messageId,
      env,
      textValue,
      replyMarkup
    );
  } else {
    await sendMessage(
      chatId,
      env,
      textValue,
      replyMarkup
    );
  }
}

function healthStateKey(deviceId) {
  return `${HEALTH_STATE_PREFIX}${deviceId}`;
}

async function alertsEnabled(env) {
  const value =
    await env.DEVICE_STATUS.get(
      ALERTS_SETTING_KEY
    );

  return value !== "0";
}

async function configureAlerts(
  chatId,
  enabled,
  env
) {
  if (enabled === null) {
    const current =
      await alertsEnabled(env);

    await sendMessage(
      chatId,
      env,
      `🔔 CẢNH BÁO TỰ ĐỘNG\n\n` +
        `Trạng thái: ${current ? "ĐANG BẬT" : "ĐANG TẮT"}\n` +
        "Máy offline: báo sau 3 phút\n" +
        "Pin yếu: từ 15% trở xuống\n" +
        "Bộ nhớ thấp: dưới 2 GB\n" +
        `Agent chuẩn: ${TARGETING_AGENT_VERSION}\n` +
        "Giờ yên lặng: 23:00–07:00\n\n" +
        "Bật: /alerts on\n" +
        "Tắt: /alerts off"
    );
    return;
  }

  await env.DEVICE_STATUS.put(
    ALERTS_SETTING_KEY,
    enabled ? "1" : "0"
  );

  if (enabled) {
    await deleteKvPrefix(
      HEALTH_STATE_PREFIX,
      env
    );

    await env.DEVICE_STATUS.delete(
      HEALTH_BOOTSTRAP_KEY
    );
  }

  await sendMessage(
    chatId,
    env,
    enabled
      ? "🔔 Đã bật cảnh báo tự động. Lần quét đầu sẽ tạo mốc ban đầu để tránh gửi hàng loạt cảnh báo cũ."
      : "🔕 Đã tắt cảnh báo tự động."
  );
}

async function countKvPrefix(
  prefix,
  env
) {
  let count = 0;
  let cursor;

  do {
    const page =
      await env.DEVICE_STATUS.list({
        prefix,
        limit: 1000,
        ...(cursor ? { cursor } : {}),
      });

    count +=
      (page.keys || []).length;

    cursor =
      page.list_complete
        ? undefined
        : page.cursor;
  } while (cursor);

  return count;
}

function vietnamHourNow() {
  try {
    const parts =
      new Intl.DateTimeFormat(
        "en-GB",
        {
          timeZone:
            "Asia/Ho_Chi_Minh",
          hour: "2-digit",
          hour12: false,
        }
      ).formatToParts(
        new Date()
      );

    const hourPart =
      parts.find(
        (part) =>
          part.type === "hour"
      );

    return Number(
      hourPart?.value
    );
  } catch (error) {
    return -1;
  }
}

function isQuietHour() {
  const hour = vietnamHourNow();

  if (
    !Number.isInteger(hour) ||
    hour < 0
  ) {
    return false;
  }

  return (
    hour >= QUIET_HOUR_START ||
    hour < QUIET_HOUR_END
  );
}

function formatHealthDuration(value) {
  const milliseconds =
    Math.max(
      0,
      Number(value) || 0
    );

  const minutes =
    Math.floor(
      milliseconds / 60000
    );

  if (minutes < 1) {
    return "dưới 1 phút";
  }

  if (minutes < 60) {
    return `${minutes} phút`;
  }

  const hours =
    Math.floor(
      minutes / 60
    );

  const remainingMinutes =
    minutes % 60;

  if (hours < 24) {
    return remainingMinutes
      ? `${hours} giờ ${remainingMinutes} phút`
      : `${hours} giờ`;
  }

  const days =
    Math.floor(hours / 24);

  const remainingHours =
    hours % 24;

  return remainingHours
    ? `${days} ngày ${remainingHours} giờ`
    : `${days} ngày`;
}

function initialHealthState(
  device,
  now,
  suppressCurrentIssues
) {
  return {
    version: 1,
    observed_online:
      device.online,
    offline_since:
      device.online
        ? null
        : now,
    offline_alert_sent:
      false,
    low_battery_alerted:
      suppressCurrentIssues
        ? device.lowBattery
        : false,
    low_storage_alerted:
      suppressCurrentIssues
        ? device.lowStorage
        : false,
    agent_old_alerted:
      suppressCurrentIssues
        ? device.oldAgent
        : false,
    last_error_alerted_key:
      suppressCurrentIssues
        ? device.errorKey
        : null,
    updated_at: now,
  };
}

async function loadHealthState(
  deviceId,
  env
) {
  try {
    const raw =
      await env.DEVICE_STATUS.get(
        healthStateKey(deviceId)
      );

    if (!raw) return null;

    const value =
      JSON.parse(raw);

    return (
      value &&
      typeof value === "object"
    )
      ? value
      : null;
  } catch (error) {
    return null;
  }
}


function healthStateChanged(
  current,
  next
) {
  const left = {
    ...(current || {}),
  };
  const right = {
    ...(next || {}),
  };
  delete left.updated_at;
  delete right.updated_at;
  return (
    JSON.stringify(left) !==
    JSON.stringify(right)
  );
}

async function saveHealthState(
  deviceId,
  state,
  env
) {
  await env.DEVICE_STATUS.put(
    healthStateKey(deviceId),
    JSON.stringify(state)
  );
}

async function collectFleetHealth(
  env,
  includeRevoked = true
) {
  const now = Date.now();

  const ids =
    await deviceIdsForTarget(
      "all",
      env
    );

  const devices = [];
  const groupLabels = new Map();

  for (const id of ids) {
    const record =
      await getDeviceRecord(
        id,
        env
      );

    if (!record) continue;

    const maintenance =
      await isDeviceMaintenance(
        id,
        env
      );

    const name =
      await deviceDisplayName(
        id,
        env
      );

    const group =
      normalizeDeviceGroup(
        record.device_group
      );

    if (
      group &&
      !groupLabels.has(group)
    ) {
      groupLabels.set(
        group,
        await getGroupLabel(
          group,
          env
        )
      );
    }

    const lastSeen =
      Number(
        record.last_seen || 0
      );

    const online =
      lastSeen > 0 &&
      now - lastSeen <=
        ONLINE_WINDOW_MS;

    const batteryNumber =
      Number(
        record.battery_level
      );

    const batteryLevel =
      Number.isFinite(
        batteryNumber
      )
        ? batteryNumber
        : null;

    const storageNumber =
      Number(
        record.storage_free_bytes
      );

    const storageFreeBytes =
      Number.isFinite(
        storageNumber
      )
        ? storageNumber
        : null;

    const lowBattery =
      batteryLevel !== null &&
      batteryLevel <=
        LOW_BATTERY_PERCENT;

    const lowStorage =
      storageFreeBytes !== null &&
      storageFreeBytes <
        LOW_STORAGE_BYTES;

    const oldAgent =
      record.agent_version !==
        TARGETING_AGENT_VERSION;

    const commandTimestamp =
      Number(
        record.last_command_ts || 0
      );

    const recentError =
      record.last_status === "error" &&
      commandTimestamp > 0 &&
      now - commandTimestamp <=
        RECENT_ERROR_WINDOW_MS;

    const errorKey =
      recentError
        ? (
            `${
              record.last_command_id ||
              "unknown"
            }:${commandTimestamp}`
          )
        : null;

    devices.push({
      id,
      name,
      group:
        groupLabels.get(group) ||
        group ||
        "-",
      record,
      maintenance,
      lastSeen,
      online,
      batteryLevel,
      storageFreeBytes,
      lowBattery,
      lowStorage,
      oldAgent,
      recentError,
      errorKey,
    });
  }

  const revoked =
    includeRevoked
      ? await countKvPrefix(
          REVOKED_PREFIX,
          env
        )
      : 0;

  const issues =
    devices.filter(
      (device) =>
        device.lowBattery ||
        device.lowStorage ||
        device.oldAgent ||
        device.recentError
    ).length;

  return {
    now,
    revoked,
    devices,
    counts: {
      total:
        devices.length,
      online:
        devices.filter(
          (device) =>
            device.online
        ).length,
      offline:
        devices.filter(
          (device) =>
            !device.online
        ).length,
      maintenance:
        devices.filter(
          (device) =>
            device.maintenance
        ).length,
      lowBattery:
        devices.filter(
          (device) =>
            device.lowBattery
        ).length,
      lowStorage:
        devices.filter(
          (device) =>
            device.lowStorage
        ).length,
      oldAgent:
        devices.filter(
          (device) =>
            device.oldAgent
        ).length,
      recentError:
        devices.filter(
          (device) =>
            device.recentError
        ).length,
      issues,
    },
  };
}

function splitTextChunks(
  lines,
  maxLength = 3500
) {
  const chunks = [];
  let current = "";

  for (const rawLine of lines) {
    const line =
      String(rawLine ?? "");

    const next =
      current
        ? `${current}\n${line}`
        : line;

    if (
      next.length > maxLength &&
      current
    ) {
      chunks.push(current);
      current = line;
    } else {
      current = next;
    }
  }

  if (current) {
    chunks.push(current);
  }

  return chunks;
}

async function sendTextChunks(
  chatId,
  env,
  lines,
  replyMarkup
) {
  const chunks =
    splitTextChunks(lines);

  for (
    let index = 0;
    index < chunks.length;
    index += 1
  ) {
    await sendMessage(
      chatId,
      env,
      chunks[index],
      index === chunks.length - 1
        ? replyMarkup
        : undefined
    );
  }
}

async function showHealth(
  chatId,
  env,
  messageId
) {
  const snapshot =
    await collectFleetHealth(
      env,
      true
    );

  const alertsOn =
    await alertsEnabled(env);

  const counts =
    snapshot.counts;

  const textValue =
    "🏥 SỨC KHỎE HỆ THỐNG\n\n" +
    `Tổng thiết bị: ${counts.total}\n` +
    `🟢 Online: ${counts.online}\n` +
    `🔴 Offline: ${counts.offline}\n` +
    `🛠 Bảo trì: ${counts.maintenance}\n` +
    `🛑 Đã thu hồi: ${snapshot.revoked}\n\n` +
    `⚠️ Pin từ ${LOW_BATTERY_PERCENT}% trở xuống: ${counts.lowBattery}\n` +
    `💾 Bộ nhớ dưới 2 GB: ${counts.lowStorage}\n` +
    `⬆️ Agent cũ: ${counts.oldAgent}\n` +
    `❌ Lệnh lỗi gần đây: ${counts.recentError}\n\n` +
    `Cảnh báo: ${alertsOn ? "ĐANG BẬT" : "ĐANG TẮT"}\n` +
    "Giờ yên lặng: 23:00–07:00";

  const replyMarkup = {
    inline_keyboard: [
      [
        {
          text:
            `🔴 OFFLINE (${counts.offline})`,
          callback_data:
            "health_offline",
        },
        {
          text:
            `⚠️ CÓ VẤN ĐỀ (${counts.issues})`,
          callback_data:
            "health_issues",
        },
      ],
      [
        {
          text:
            `⬆️ AGENT CŨ (${counts.oldAgent})`,
          callback_data:
            "health_agent",
        },
        {
          text: "📋 TẤT CẢ MÁY",
          callback_data:
            "show_devices",
        },
      ],
      [
        {
          text:
            alertsOn
              ? "🔔 CẢNH BÁO: BẬT"
              : "🔕 CẢNH BÁO: TẮT",
          callback_data:
            "alerts_status",
        },
        {
          text: "⬅️ MENU",
          callback_data:
            "menu",
        },
      ],
    ],
  };

  if (messageId) {
    await editMessage(
      chatId,
      messageId,
      env,
      textValue,
      replyMarkup
    );
  } else {
    await sendMessage(
      chatId,
      env,
      textValue,
      replyMarkup
    );
  }
}

async function showHealthList(
  chatId,
  filter,
  env
) {
  const snapshot =
    await collectFleetHealth(
      env,
      false
    );

  let selected;
  let title;

  if (filter === "offline") {
    selected =
      snapshot.devices.filter(
        (device) =>
          !device.online
      );

    title =
      "🔴 THIẾT BỊ OFFLINE";
  } else if (filter === "agent") {
    selected =
      snapshot.devices.filter(
        (device) =>
          device.oldAgent
      );

    title =
      "⬆️ THIẾT BỊ DÙNG AGENT CŨ";
  } else {
    selected =
      snapshot.devices.filter(
        (device) =>
          device.lowBattery ||
          device.lowStorage ||
          device.oldAgent ||
          device.recentError
      );

    title =
      "⚠️ THIẾT BỊ CÓ VẤN ĐỀ";
  }

  if (selected.length === 0) {
    await sendMessage(
      chatId,
      env,
      `${title}\n\nKhông có thiết bị phù hợp.`,
      {
        inline_keyboard: [
          [
            {
              text: "⬅️ SỨC KHỎE",
              callback_data:
                "show_health",
            },
          ],
        ],
      }
    );
    return;
  }

  selected.sort(
    (left, right) =>
      left.name.localeCompare(
        right.name,
        "vi",
        {
          numeric: true,
          sensitivity: "base",
        }
      )
  );

  const lines = [
    `${title}: ${selected.length}`,
    "",
  ];

  for (const device of selected) {
    const flags = [];

    if (!device.online) {
      flags.push(
        `Offline ${formatRelativeDeviceTime(device.lastSeen, snapshot.now)}`
      );
    }

    if (device.lowBattery) {
      flags.push(
        `Pin ${device.batteryLevel}%`
      );
    }

    if (device.lowStorage) {
      flags.push(
        `Trống ${formatByteCount(device.storageFreeBytes)}`
      );
    }

    if (device.oldAgent) {
      flags.push(
        `Agent ${
          device.record.agent_version ||
          "bản cũ"
        }`
      );
    }

    if (device.recentError) {
      flags.push(
        "Có lệnh lỗi gần đây"
      );
    }

    if (device.maintenance) {
      flags.push(
        "Đang bảo trì"
      );
    }

    lines.push(
      `${device.online ? "🟢" : "⚪"} ${device.name}`,
      `ID: ${device.id}`,
      `Nhóm: ${device.group}`,
      `Vấn đề: ${flags.join(", ") || "-"}`,
      ""
    );
  }

  await sendTextChunks(
    chatId,
    env,
    lines,
    {
      inline_keyboard: [
        [
          {
            text: "⬅️ SỨC KHỎE",
            callback_data:
              "show_health",
          },
          {
            text: "📋 DANH SÁCH",
            callback_data:
              "show_devices",
          },
        ],
      ],
    }
  );
}

async function checkFleetHealth(env) {
  try {
    if (
      !(await alertsEnabled(env))
    ) {
      return;
    }

    const snapshot =
      await collectFleetHealth(
        env,
        false
      );

    const now =
      snapshot.now;

    const quiet =
      isQuietHour();

    const bootstrapped =
      (
        await env.DEVICE_STATUS.get(
          HEALTH_BOOTSTRAP_KEY
        )
      ) === "1";

    const alertEntries = [];
    const finalStates = new Map();

    for (
      const device of snapshot.devices
    ) {
      let state =
        await loadHealthState(
          device.id,
          env
        );

      if (
        !state ||
        state.version !== 1
      ) {
        state =
          initialHealthState(
            device,
            now,
            !bootstrapped
          );

        await saveHealthState(
          device.id,
          state,
          env
        );

        if (!bootstrapped) {
          continue;
        }
      } else {
        state = {
          ...state,
        };
      }

      if (device.maintenance) {
        const maintenanceState =
          initialHealthState(
            device,
            now,
            true
          );
        if (
          healthStateChanged(
            state,
            maintenanceState
          )
        ) {
          await saveHealthState(
            device.id,
            maintenanceState,
            env
          );
        }
        continue;
      }

      if (
        typeof state.observed_online !==
        "boolean"
      ) {
        state.observed_online =
          device.online;
      }

      if (
        state.observed_online !==
        device.online
      ) {
        state.observed_online =
          device.online;

        if (!device.online) {
          state.offline_since =
            now;
          state.offline_alert_sent =
            false;
        } else if (
          !state.offline_alert_sent
        ) {
          state.offline_since =
            null;
        }
      }

      if (
        device.batteryLevel !== null &&
        device.batteryLevel >=
          BATTERY_RECOVERY_PERCENT
      ) {
        state.low_battery_alerted =
          false;
      }

      if (
        device.storageFreeBytes !==
          null &&
        device.storageFreeBytes >=
          STORAGE_RECOVERY_BYTES
      ) {
        state.low_storage_alerted =
          false;
      }

      if (!device.oldAgent) {
        state.agent_old_alerted =
          false;
      }

      state.updated_at = now;

      const finalState = {
        ...state,
      };

      if (!device.online) {
        if (
          !state.offline_since
        ) {
          state.offline_since =
            now;
          finalState.offline_since =
            now;
        }

        if (
          !quiet &&
          !state.offline_alert_sent &&
          now -
            Number(
              state.offline_since
            ) >=
            OFFLINE_ALERT_AFTER_MS
        ) {
          alertEntries.push(
            `🔴 ${device.name} đã mất kết nối\n` +
              `ID: ${device.id}\n` +
              `Heartbeat cuối: ${formatRelativeDeviceTime(device.lastSeen, now)}`
          );

          finalState.offline_alert_sent =
            true;
        }
      } else if (
        state.offline_alert_sent
      ) {
        if (!quiet) {
          alertEntries.push(
            `🟢 ${device.name} đã online trở lại\n` +
              `ID: ${device.id}\n` +
              `Gián đoạn: ${formatHealthDuration(now - Number(state.offline_since || now))}`
          );

          finalState.offline_alert_sent =
            false;
          finalState.offline_since =
            null;
        }
      } else {
        state.offline_since =
          null;
        finalState.offline_since =
          null;
      }

      if (
        device.lowBattery &&
        !state.low_battery_alerted &&
        !quiet
      ) {
        alertEntries.push(
          `🔋 ${device.name} sắp hết pin\n` +
            `ID: ${device.id}\n` +
            `Pin còn: ${device.batteryLevel}%`
        );

        finalState.low_battery_alerted =
          true;
      }

      if (
        device.lowStorage &&
        !state.low_storage_alerted &&
        !quiet
      ) {
        alertEntries.push(
          `💾 ${device.name} sắp hết bộ nhớ\n` +
            `ID: ${device.id}\n` +
            `Dung lượng trống: ${formatByteCount(device.storageFreeBytes)}`
        );

        finalState.low_storage_alerted =
          true;
      }

      if (
        device.oldAgent &&
        !state.agent_old_alerted &&
        !quiet
      ) {
        alertEntries.push(
          `⬆️ ${device.name} đang dùng Agent cũ\n` +
            `ID: ${device.id}\n` +
            `Hiện tại: ${device.record.agent_version || "không rõ"}\n` +
            `Yêu cầu: ${TARGETING_AGENT_VERSION}`
        );

        finalState.agent_old_alerted =
          true;
      }

      if (
        device.recentError &&
        device.errorKey !==
          state.last_error_alerted_key &&
        !quiet
      ) {
        alertEntries.push(
          `❌ ${device.name} báo lỗi lệnh\n` +
            `ID: ${device.id}\n` +
            `Lệnh: ${device.record.last_command || "-"}\n` +
            `Kết quả: ${String(device.record.last_result || "-").slice(0, 200)}`
        );

        finalState.last_error_alerted_key =
          device.errorKey;
      }

      finalState.updated_at =
        now;

      if (
        healthStateChanged(
          state,
          finalState
        )
      ) {
        finalStates.set(
          device.id,
          finalState
        );
      }
    }

    if (alertEntries.length > 0) {
      const lines = [
        "🚨 CẢNH BÁO HỆ THỐNG",
        "",
      ];

      for (
        const entry of alertEntries
      ) {
        lines.push(
          entry,
          ""
        );
      }

      await sendTextChunks(
        String(
          env.TELEGRAM_ADMIN_USER_ID
        ),
        env,
        lines
      );

    }

    for (
      const [deviceId, nextState]
      of finalStates
    ) {
      await saveHealthState(
        deviceId,
        nextState,
        env
      );
    }

    if (!bootstrapped) {
      await env.DEVICE_STATUS.put(
        HEALTH_BOOTSTRAP_KEY,
        "1"
      );
    }
  } catch (error) {
    console.error(
      "fleet_health_check_failed",
      error?.message || error
    );
  }
}

async function showDevices(chatId, env) {
  const now = Date.now();

  const ids =
    await deviceIdsForTarget(
      "all",
      env
    );

  const devices = [];

  for (const id of ids) {
    const record =
      await getDeviceRecord(id, env);

    if (!record) continue;

    const online =
      now - Number(
        record.last_seen || 0
      ) <= ONLINE_WINDOW_MS;

    const maintenance =
      await isDeviceMaintenance(
        id,
        env
      );

    const name =
      await deviceDisplayName(
        id,
        env
      );

    const groupLabel =
      await getGroupLabel(
        record.device_group,
        env
      );

    devices.push({
      id,
      name,
      online,
      maintenance,
      groupLabel,
      activity:
        formatRelativeDeviceTime(
          record.last_seen,
          now
        ),
      status:
        maintenance
          ? "Đang bảo trì"
          : deviceStatusLabel(
              record,
              online
            ),
    });
  }

  if (devices.length === 0) {
    await sendMessage(
      chatId,
      env,
      "📋 THIẾT BỊ: 0\n\nChưa có thiết bị nào kết nối."
    );
    return;
  }

  devices.sort((left, right) => {
    if (
      left.maintenance !==
      right.maintenance
    ) {
      return left.maintenance
        ? 1
        : -1;
    }

    if (
      left.online !== right.online
    ) {
      return left.online ? -1 : 1;
    }

    return left.name.localeCompare(
      right.name,
      "vi",
      {
        numeric: true,
        sensitivity: "base",
      }
    );
  });

  const lines = [
    `📋 THIẾT BỊ: ${devices.length}`,
    "",
  ];

  for (const device of devices) {
    const icon =
      device.maintenance
        ? "🛠"
        : device.online
          ? "🟢"
          : "⚪";

    lines.push(
      `${icon} ${device.name}`,
      `ID: ${device.id}`,
      `Nhóm: ${device.groupLabel}`,
      `Hoạt động: ${device.activity}`,
      `Trạng thái: ${device.status}`,
      ""
    );
  }

  const buttons = [];

  for (
    let index = 0;
    index < devices.length;
    index += 2
  ) {
    buttons.push(
      devices
        .slice(index, index + 2)
        .map((device) => ({
          text:
            `${
              device.maintenance
                ? "🛠"
                : device.online
                  ? "🟢"
                  : "⚪"
            } ${device.name.slice(0, 22)}`,
          callback_data:
            `device:${device.id}`,
        }))
    );
  }

  let chunk = "";

  for (const line of lines) {
    const next =
      chunk
        ? `${chunk}\n${line}`
        : line;

    if (next.length > 3500) {
      await sendMessage(
        chatId,
        env,
        chunk.trim()
      );
      chunk = line;
    } else {
      chunk = next;
    }
  }

  if (chunk) {
    await sendMessage(
      chatId,
      env,
      chunk.trim(),
      {
        inline_keyboard: buttons,
      }
    );
  }
}


async function sendProgress(chatId, env) {
  try {
    let commandId = null;
    let metadata = null;

    const latestRaw =
      await env.DEVICE_STATUS.get(
        "latest_command"
      );

    if (latestRaw) {
      try {
        const latest =
          JSON.parse(latestRaw);

        commandId =
          latest.command_id || null;
      } catch (error) {
        commandId =
          latestRaw.trim() || null;
      }
    }

    if (commandId) {
      const metadataRaw =
        await env.DEVICE_STATUS.get(
          `cmd:${commandId}`
        );

      if (metadataRaw) {
        try {
          metadata =
            JSON.parse(metadataRaw);
        } catch (error) {
          metadata = null;
        }
      }
    }

    // Fallback cho command cũ chưa có latest_command.
    if (!commandId) {
      let newestTimestamp = 0;

      const allDeviceIds =
        await deviceIdsForTarget(
          "all",
          env
        );

      for (const deviceId of allDeviceIds) {
        const record =
          await getDeviceRecord(
            deviceId,
            env
          );

        if (
          record?.last_command_id &&
          Number(
            record.last_command_ts || 0
          ) > newestTimestamp
        ) {
          commandId =
            record.last_command_id;

          newestTimestamp =
            Number(
              record.last_command_ts || 0
            );
        }
      }

      if (commandId) {
        const metadataRaw =
          await env.DEVICE_STATUS.get(
            `cmd:${commandId}`
          );

        if (metadataRaw) {
          try {
            metadata =
              JSON.parse(metadataRaw);
          } catch (error) {
            metadata = null;
          }
        }

        if (!metadata) {
          metadata = {
            command_id: commandId,
            target: "all",
            commands: [],
            command_count: 0,
            device_count:
              allDeviceIds.length,
            device_ids:
              allDeviceIds,
            created:
              newestTimestamp,
          };
        }
      }
    }

    if (!commandId) {
      await sendMessage(
        chatId,
        env,
        "Không tìm thấy command gần đây để báo tiến độ."
      );
      return;
    }

    const target =
      ["all", "marmot", "nova", "devices"].includes(
        metadata?.target
      )
        ? metadata.target
        : "all";

    const deviceIds =
      Array.isArray(metadata?.device_ids) &&
      metadata.device_ids.length > 0
        ? [
            ...new Set(
              metadata.device_ids
                .map(normalizeDeviceId)
                .filter(Boolean)
            ),
          ].sort(compareDeviceIds)
        : await deviceIdsForTarget(
            target,
            env
          );

    const commands =
      Array.isArray(metadata?.commands)
        ? metadata.commands
        : [];

    const counts = {
      received: 0,
      running: 0,
      success: 0,
      error: 0,
      offline: 0,
      no_response: 0,
    };

    const now = Date.now();

    for (const deviceId of deviceIds) {
      const record =
        await getDeviceRecord(
          deviceId,
          env
        );

      if (
        !record ||
        now - Number(
          record.last_seen || 0
        ) > 90 * 1000
      ) {
        counts.offline += 1;
        continue;
      }

      if (
        record.last_command_id !==
        commandId
      ) {
        counts.no_response += 1;
        continue;
      }

      switch (record.last_status) {
        case "received":
          counts.received += 1;
          break;

        case "running":
          counts.running += 1;
          break;

        case "success":
          counts.success += 1;
          break;

        case "error":
          counts.error += 1;
          break;

        default:
          counts.no_response += 1;
          break;
      }
    }

    const lines = [
      `📊 Tiến độ command: ${commandId}`,
      `Đích: ${metadata?.target_label || target.toUpperCase()}`,
      `Thời gian tạo: ${
        formatTimestamp(metadata?.created)
      }`,
    ];

    if (commands.length > 0) {
      lines.push(
        `Lệnh (${commands.length}):`,
        ...commands.map(
          (command) => `- ${command}`
        )
      );
    } else {
      lines.push(
        "Lệnh: chưa có metadata của command cũ"
      );
    }

    lines.push(
      `Tổng máy dự kiến: ${deviceIds.length}`,
      `Received: ${counts.received}`,
      `Running: ${counts.running}`,
      `Success: ${counts.success}`,
      `Error: ${counts.error}`,
      `Offline: ${counts.offline}`,
      `No response: ${counts.no_response}`
    );

    await sendMessage(
      chatId,
      env,
      lines.join("\n")
    );

  } catch (error) {
    await sendMessage(
      chatId,
      env,
      `Lỗi khi tổng hợp tiến độ: ${error.message}`
    );
  }
}

function text(value, status = 200) {
  return new Response(value, {
    status,
    headers: { "Content-Type": "text/plain; charset=utf-8" },
  });
}

function json(value, status = 200) {
  return new Response(JSON.stringify(value, null, 2), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" },
  });
}

function noStoreJson(value, status = 200) {
  return new Response(JSON.stringify(value), {
    status,
    headers: {
      "Content-Type":
        "application/json; charset=utf-8",
      "Cache-Control":
        "no-store, no-cache, must-revalidate",
      Pragma: "no-cache",
    },
  });
}

// === DISCORD INTEGRATION ===
function hexToUint8Array(hex) {
  return new Uint8Array(hex.match(/.{1,2}/g).map(byte => parseInt(byte, 16)));
}

async function verifyDiscordSignature(signature, timestamp, body, publicKeyHex) {
  try {
    const sig = hexToUint8Array(signature);
    const keyBytes = hexToUint8Array(publicKeyHex);
    const data = new TextEncoder().encode(timestamp + body);
    try {
      const key = await crypto.subtle.importKey("raw", keyBytes, "Ed25519", false, ["verify"]);
      return await crypto.subtle.verify("Ed25519", key, sig, data);
    } catch (e) {
      const key = await crypto.subtle.importKey("raw", keyBytes, {name: "NODE-ED25519", namedCurve: "NODE-ED25519"}, false, ["verify"]);
      return await crypto.subtle.verify("NODE-ED25519", key, sig, data);
    }
  } catch(e) {
    return false;
  }
}

async function handleDiscordInteraction(interaction, env) {
  if (String(interaction.member?.user?.id || interaction.user?.id) !== String(env.DISCORD_ADMIN_USER_ID)) {
    return;
  }

  let input = "";
  if (interaction.data?.name === "aot") {
    input = interaction.data?.options?.find(o => o.name === "input")?.value || "";
    input = input.trim();
    if (input && !input.startsWith("/")) input = `/${input}`;
  } else {
    input = `/${interaction.data?.name}`;
    if (interaction.data?.options) {
      for (const opt of interaction.data?.options) {
        input += ` ${opt.value}`;
      }
    }
  }

  const update = {
    message: {
      from: { id: env.TELEGRAM_ADMIN_USER_ID },
      chat: { id: `discord:${interaction.application_id}:${interaction.token}` },
      text: input
    }
  };

  await handleUpdate(update, env);
}

async function handleDiscordComponent(interaction, env) {
  if (String(interaction.member?.user?.id || interaction.user?.id) !== String(env.DISCORD_ADMIN_USER_ID)) {
    return;
  }
  const customId = interaction.data?.custom_id;
  const update = {
    callback_query: {
      id: `discord:${interaction.application_id}:${interaction.token}`,
      from: { id: env.TELEGRAM_ADMIN_USER_ID },
      message: {
        chat: { id: `discord:${interaction.application_id}:${interaction.token}` },
        message_id: "@original"
      },
      data: customId
    }
  };
  await handleUpdate(update, env);
}
